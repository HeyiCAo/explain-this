import { a as recordUsage, c as require_react, l as __toESM, s as require_client, t as require_jsx_runtime } from "./jsx-runtime-BlGLasjB.js";
//#region src/styles.css
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_client = /* @__PURE__ */ __toESM(require_client(), 1);
//#endregion
//#region src/shared/apiService.js
var AIService = class {
	constructor() {
		this.apiKey = null;
		this.provider = "openai";
		this.baseURL = "https://api.deepseek.com/v1";
		this.model = "deepseek-chat";
		this.geminiBaseURL = "https://generativelanguage.googleapis.com/v1";
		this.geminiModel = "gemini-3.5-flash";
		this.openaiBaseURL = "https://api.openai.com/v1";
		this.openaiModel = "gpt-4o-mini";
	}
	async loadApiKey() {
		return new Promise((resolve) => {
			chrome.storage.local.get([
				"apiKey",
				"geminiApiKey",
				"openaiApiKey",
				"provider"
			], (result) => {
				this.provider = result.provider || "openai";
				if (this.provider === "gemini") this.apiKey = result.geminiApiKey || "";
				else if (this.provider === "openai") this.apiKey = result.openaiApiKey || "";
				else this.apiKey = result.apiKey || "";
				resolve(this.apiKey);
			});
		});
	}
	async explainText(text, options = {}) {
		await this.loadApiKey();
		if (!this.apiKey) throw new Error("Please set up an API key first");
		const prompt = this.buildPrompt(text, options);
		const language = options.language || "zh";
		const isFast = (options.speed || "fast") === "fast";
		const systemContent = this.buildSystemContent(language, isFast);
		if (this.provider === "gemini") return this.explainWithGemini(prompt, isFast, systemContent);
		const apiUrl = this.provider === "openai" ? this.openaiBaseURL : this.baseURL;
		const apiModel = this.provider === "openai" ? this.openaiModel : this.model;
		const response = await fetch(`${apiUrl}/chat/completions`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"Authorization": `Bearer ${this.apiKey}`
			},
			body: JSON.stringify({
				model: apiModel,
				messages: [{
					role: "system",
					content: systemContent
				}, {
					role: "user",
					content: prompt
				}],
				max_tokens: isFast ? 800 : 2e3,
				temperature: isFast ? .1 : .4
			})
		});
		if (!response.ok) throw new Error(`API Call Failure (HTTP ${response.status}): ${await this.readError(response)}`);
		const data = await response.json();
		return this.formatExplanation(data.choices?.[0]?.message?.content || "");
	}
	async explainTextStream(text, options = {}, onChunk = () => {}) {
		await this.loadApiKey();
		if (!this.apiKey) throw new Error("Please set up an API key first");
		const prompt = this.buildPrompt(text, options);
		const language = options.language || "zh";
		const isFast = (options.speed || "fast") === "fast";
		const systemContent = this.buildSystemContent(language, isFast);
		if (this.provider === "gemini") return this.explainGeminiStream(prompt, isFast, systemContent, onChunk);
		const apiUrl = this.provider === "openai" ? this.openaiBaseURL : this.baseURL;
		const apiModel = this.provider === "openai" ? this.openaiModel : this.model;
		const response = await fetch(`${apiUrl}/chat/completions`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"Authorization": `Bearer ${this.apiKey}`
			},
			body: JSON.stringify({
				model: apiModel,
				messages: [{
					role: "system",
					content: systemContent
				}, {
					role: "user",
					content: prompt
				}],
				max_tokens: isFast ? 800 : 2e3,
				temperature: isFast ? .1 : .4,
				stream: true
			})
		});
		if (!response.ok) throw new Error(`API Call Failure (HTTP ${response.status}): ${await this.readError(response)}`);
		const fullText = await this.readSseStream(response, (data) => {
			const delta = data.choices?.[0]?.delta?.content || "";
			if (delta) onChunk(delta);
			return delta;
		});
		return this.formatExplanation(fullText);
	}
	async explainGeminiStream(prompt, isFast, systemContent, onChunk) {
		const response = await fetch(`${this.geminiBaseURL}/models/${this.geminiModel}:streamGenerateContent?alt=sse`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"x-goog-api-key": this.apiKey
			},
			body: JSON.stringify({
				systemInstruction: { parts: [{ text: systemContent }] },
				contents: [{
					role: "user",
					parts: [{ text: prompt }]
				}],
				generationConfig: {
					maxOutputTokens: isFast ? 800 : 2e3,
					temperature: isFast ? .1 : .4
				}
			})
		});
		if (!response.ok) throw new Error(`API Call Failure (HTTP ${response.status}): ${await this.readError(response)}`);
		const fullText = await this.readSseStream(response, (data) => {
			const delta = (data.candidates?.[0]?.content?.parts || []).map((part) => part.text || "").join("");
			if (delta) onChunk(delta);
			return delta;
		});
		return this.formatExplanation(fullText);
	}
	async readSseStream(response, extractDelta) {
		const reader = response.body?.getReader();
		if (!reader) throw new Error("Streaming response is not supported in this browser");
		const decoder = new TextDecoder();
		let buffer = "";
		let fullText = "";
		while (true) {
			const { value, done } = await reader.read();
			if (done) break;
			buffer += decoder.decode(value, { stream: true });
			const lines = buffer.split(/\r?\n/);
			buffer = lines.pop() || "";
			for (const line of lines) {
				const trimmed = line.trim();
				if (!trimmed.startsWith("data:")) continue;
				const payload = trimmed.slice(5).trim();
				if (!payload || payload === "[DONE]") continue;
				try {
					const delta = extractDelta(JSON.parse(payload));
					fullText += delta || "";
				} catch (error) {
					console.warn("Failed to parse stream chunk", error);
				}
			}
		}
		return fullText;
	}
	buildSystemContent(language, isFast) {
		return `${isFast ? language === "en" ? "You are a highly concise dictionary assistant. Provide ONLY a single short paragraph (maximum 3 sentences) summarizing the core meaning. Do NOT output any bullet points, lists, examples, or extra details." : "你是一个极简词典助手。请仅用一段简短的话（最多3句话）总结核心含义。绝不能输出任何列表、要点、例子或多余细节，说完即止。" : language === "en" ? "You are a professional explainer. Use simple language and include helpful examples." : "你是一个专业的解释助手。请用简单易懂的语言详细解释用户输入的内容。"}
${!isFast ? language === "en" ? "Format: first give a one-sentence summary, then explain in bullets, then include a relevant example." : "格式要求：1. 第一行用一句话总结 2. 然后分点详细解释 3. 最后给出相关例子" : ""}
${language === "en" ? "Use English for the entire response." : "请全程使用中文回答。"}`;
	}
	async explainWithGemini(prompt, isFast, systemContent) {
		const response = await fetch(`${this.geminiBaseURL}/models/${this.geminiModel}:generateContent`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"x-goog-api-key": this.apiKey
			},
			body: JSON.stringify({
				systemInstruction: { parts: [{ text: systemContent }] },
				contents: [{
					role: "user",
					parts: [{ text: prompt }]
				}],
				generationConfig: {
					maxOutputTokens: isFast ? 800 : 2e3,
					temperature: isFast ? .1 : .4
				}
			})
		});
		if (!response.ok) throw new Error(`API Call Failure (HTTP ${response.status}): ${await this.readError(response)}`);
		const text = ((await response.json()).candidates?.[0]?.content?.parts || []).map((part) => part.text || "").join("");
		return this.formatExplanation(text);
	}
	async readError(response) {
		try {
			return JSON.stringify(await response.json());
		} catch {
			return response.text();
		}
	}
	buildPrompt(text, options) {
		let prompt = `${(options.language || "zh") === "en" ? "Explain:" : "请解释："}${text}`;
		if (options.context) prompt += `\n上下文：${options.context}`;
		return prompt;
	}
	formatExplanation(explanation) {
		const html = this.escapeHtml(explanation).replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>").replace(/\*(.*?)\*/g, "<em>$1</em>").replace(/`(.*?)`/g, "<code>$1</code>").replace(/\n/g, "<br>");
		return this.sanitizeHtml(this.renderMath(html));
	}
	escapeHtml(text) {
		return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
	}
	sanitizeHtml(html) {
		const allowedTags = new Set([
			"strong",
			"em",
			"code",
			"br",
			"span",
			"div",
			"sub",
			"sup"
		]);
		const allowedClass = new Set([
			"math-inline",
			"math-display",
			"frac",
			"num",
			"den",
			"op"
		]);
		const template = document.createElement("template");
		template.innerHTML = html;
		const walk = (node) => {
			Array.from(node.childNodes).forEach((child) => {
				if (child.nodeType !== Node.ELEMENT_NODE) return;
				const tag = child.tagName.toLowerCase();
				if (!allowedTags.has(tag)) {
					child.replaceWith(document.createTextNode(child.textContent || ""));
					return;
				}
				Array.from(child.attributes).forEach((attr) => {
					if (attr.name === "class") {
						const classes = attr.value.split(/\s+/).filter((className) => allowedClass.has(className));
						classes.length ? child.setAttribute("class", classes.join(" ")) : child.removeAttribute("class");
					} else child.removeAttribute(attr.name);
				});
				walk(child);
			});
		};
		walk(template.content);
		return template.innerHTML;
	}
	renderMath(html) {
		let out = html;
		out = out.replace(/\\\[((?:.|\n)*?)\\\]/g, (match, content) => {
			return `<div class="math-display">${this.latexToHtml(content)}</div>`;
		});
		out = out.replace(/\\\((.*?)\\\)/g, (match, content) => {
			return `<span class="math-inline">${this.latexToHtml(content)}</span>`;
		});
		return out;
	}
	latexToHtml(latex) {
		if (!latex) return "";
		let s = latex;
		s = s.replace(/\\Delta/g, "Δ").replace(/\\to/g, "→").replace(/\\infty/g, "∞").replace(/\\cdot/g, "·").replace(/\\times/g, "×").replace(/\\leq/g, "≤").replace(/\\geq/g, "≥");
		for (let i = 0; i < 3; i += 1) s = s.replace(/\\frac\{([^{}]+)\}\{([^{}]+)\}/g, (match, a, b) => {
			return `<span class="frac"><span class="num">${a}</span><span class="den">${b}</span></span>`;
		});
		s = s.replace(/_({[^}]+}|[^\s^_])/g, (match) => {
			return `<sub>${match.slice(1).replace(/^\{|\}$/g, "")}</sub>`;
		});
		s = s.replace(/\^({[^}]+}|[^\s^_])/g, (match) => {
			return `<sup>${match.slice(1).replace(/^\{|\}$/g, "")}</sup>`;
		});
		s = s.replace(/\\lim<sub>(.*?)<\/sub>/g, (match, sub) => `<span class="op">lim</span><sub>${sub}</sub>`);
		return s.replace(/\\lim/g, "<span class=\"op\">lim</span>");
	}
};
//#endregion
//#region src/popup/popup.jsx
var import_jsx_runtime = require_jsx_runtime();
var hasExtensionStorage = () => typeof chrome !== "undefined" && chrome?.storage?.local;
var getStorage = (keys) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve({});
		return;
	}
	chrome.storage.local.get(keys, resolve);
});
var setStorage = (values) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve();
		return;
	}
	chrome.storage.local.set(values, resolve);
});
var popupZh = {
	app_title: "Explain This",
	input_placeholder: "粘贴或输入你不懂的内容...\n例如：'内卷是什么意思？'\n      'Python中的装饰器怎么理解？'\n      '这个历史典故有什么背景？'",
	ask_ai: "发送",
	speed_label: "速度",
	speed_fast: "快",
	speed_detail: "详",
	results_title: "结果",
	thinking: "思考中...",
	history_title: "最近记录",
	clear_history: "清空",
	empty_input: "请输入要解释的内容",
	api_error_prefix: "解释失败：",
	retry: "重试"
};
var popupEn = {
	app_title: "Explain This",
	input_placeholder: "Paste or type what you don't understand...",
	ask_ai: "Ask",
	speed_label: "Speed",
	speed_fast: "Fast",
	speed_detail: "Detail",
	results_title: "Results",
	thinking: "Thinking...",
	history_title: "Recent",
	clear_history: "Clear",
	empty_input: "Please enter text to explain",
	api_error_prefix: "Failed to explain: ",
	retry: "Try Again"
};
function useSimpleCache() {
	const cacheRef = (0, import_react.useRef)({});
	(0, import_react.useEffect)(() => {
		getStorage(["explainCache"]).then((result) => {
			const list = result.explainCache || [];
			const newCache = { ...cacheRef.current };
			list.forEach((item) => {
				if (item && item.key) newCache[item.key] = item;
			});
			cacheRef.current = newCache;
		});
	}, []);
	const normalizeKey = (text, language, speed) => {
		const base = text.trim();
		if (!language) return base;
		if (!speed) return `${base}::${language}`;
		return `${base}::${language}::${speed}`;
	};
	return {
		getCache: (0, import_react.useCallback)((text, language, speed) => {
			const key = normalizeKey(text, language, speed);
			return cacheRef.current[key] || null;
		}, []),
		upsertCache: (0, import_react.useCallback)((text, explanation, language, speed) => {
			const key = normalizeKey(text, language, speed);
			cacheRef.current[key] = {
				key,
				text: text.substring(0, 200),
				explanation,
				language,
				speed,
				updatedAt: Date.now()
			};
			getStorage(["explainCache"]).then((result) => {
				const list = result.explainCache || [];
				setStorage({ explainCache: [cacheRef.current[key], ...list.filter((i) => i.key !== key)].slice(0, 100) });
			});
		}, [])
	};
}
function HistoryItem({ item, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "history-item",
		onClick,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "history-item-text",
			children: item.text
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "history-item-meta",
			children: [
				(item.language || "zh").toUpperCase(),
				" · ",
				item.timestamp
			]
		})]
	});
}
function LoadingSpinner({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "loading-container",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "spinner" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "loading-text",
			children: text
		})]
	});
}
function ResultError({ message }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "result-error",
		children: message
	});
}
function ResultSuccess({ html }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		id: "resultContent",
		className: "result-content",
		dangerouslySetInnerHTML: { __html: html }
	});
}
function ResultStreaming({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stream-container",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "stream-content",
			children: text
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "stream-cursor",
			children: "▊"
		})]
	});
}
function Popup() {
	const [inputText, setInputText] = (0, import_react.useState)("");
	const [language, setLanguage] = (0, import_react.useState)("en");
	const [speed, setSpeed] = (0, import_react.useState)("fast");
	const [result, setResult] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [showResult, setShowResult] = (0, import_react.useState)(false);
	const [historyList, setHistoryList] = (0, import_react.useState)([]);
	const [langMenuOpen, setLangMenuOpen] = (0, import_react.useState)(false);
	const langWrapRef = (0, import_react.useRef)(null);
	const aiServiceRef = (0, import_react.useRef)(new AIService());
	const { getCache, upsertCache } = useSimpleCache();
	const t = language === "zh" ? popupZh : popupEn;
	(0, import_react.useEffect)(() => {
		getStorage([
			"lang",
			"explainSpeed",
			"history",
			"lastSelectedText",
			"shouldAutoFill"
		]).then((result) => {
			let currentLang = language;
			let currentSpeed = speed;
			if (result.lang) {
				setLanguage(result.lang);
				currentLang = result.lang;
			}
			if (result.explainSpeed) {
				setSpeed(result.explainSpeed);
				currentSpeed = result.explainSpeed;
			}
			if (result.history) setHistoryList(result.history);
			if (result.shouldAutoFill && result.lastSelectedText) {
				const text = result.lastSelectedText;
				setInputText(text);
				setLoading(true);
				setShowResult(true);
				setResult({
					type: "streaming",
					text: ""
				});
				aiServiceRef.current.explainTextStream(text, {
					language: currentLang,
					speed: currentSpeed
				}, (chunk) => {
					setResult((prev) => ({
						type: "streaming",
						text: (prev.text || "") + chunk
					}));
				}).then((html) => {
					setResult({
						type: "success",
						html
					});
					recordUsage({
						inputText: text,
						outputText: html.replace(/<[^>]+>/g, "")
					});
					upsertCache(text, html, currentLang, currentSpeed);
					setHistoryList((currentHistory) => {
						const newHistory = [{
							key: text,
							text: text.substring(0, 50),
							timestamp: (/* @__PURE__ */ new Date()).toLocaleString(),
							language: currentLang,
							speed: currentSpeed
						}, ...currentHistory.filter((h) => h.key !== text)].slice(0, 10);
						setStorage({ history: newHistory });
						return newHistory;
					});
				}).catch((error) => {
					setResult({
						type: "error",
						message: `${(currentLang === "zh" ? popupZh : popupEn).api_error_prefix}${error.message}`
					});
				}).finally(() => {
					setLoading(false);
					setStorage({
						shouldAutoFill: false,
						lastSelectedText: ""
					});
				});
			}
		});
	}, []);
	(0, import_react.useEffect)(() => {
		if (!langMenuOpen) return;
		const handler = (e) => {
			if (langWrapRef.current && !langWrapRef.current.contains(e.target)) setLangMenuOpen(false);
		};
		document.addEventListener("click", handler);
		return () => document.removeEventListener("click", handler);
	}, [langMenuOpen]);
	const explainText = (0, import_react.useCallback)(async (rawText, overrideLang, overrideSpeed) => {
		const text = rawText.trim();
		if (!text) {
			setResult({
				type: "error",
				message: t.empty_input
			});
			setShowResult(true);
			return;
		}
		const currentLang = overrideLang || language;
		const currentSpeed = overrideSpeed || speed;
		const cached = getCache(text, currentLang, currentSpeed);
		if (cached?.explanation) {
			setResult({
				type: "success",
				html: cached.explanation
			});
			setShowResult(true);
			return;
		}
		setLoading(true);
		setShowResult(true);
		setResult({
			type: "streaming",
			text: ""
		});
		try {
			let streamedText = "";
			const html = await aiServiceRef.current.explainTextStream(text, {
				language: currentLang,
				speed: currentSpeed
			}, (chunk) => {
				streamedText += chunk;
				setResult({
					type: "streaming",
					text: streamedText
				});
			});
			setResult({
				type: "success",
				html
			});
			recordUsage({
				inputText: text,
				outputText: streamedText
			});
			upsertCache(text, html, currentLang, currentSpeed);
			setHistoryList((currentHistory) => {
				const newHistory = [{
					key: text,
					text: text.substring(0, 50),
					timestamp: (/* @__PURE__ */ new Date()).toLocaleString(),
					language: currentLang,
					speed: currentSpeed
				}, ...currentHistory.filter((h) => h.key !== text)].slice(0, 10);
				setStorage({ history: newHistory });
				return newHistory;
			});
		} catch (error) {
			setResult({
				type: "error",
				message: `${t.api_error_prefix}${error.message}`
			});
		} finally {
			setLoading(false);
		}
	}, [
		language,
		speed,
		getCache,
		upsertCache,
		t
	]);
	const handleSubmit = (0, import_react.useCallback)(() => {
		explainText(inputText);
	}, [inputText, explainText]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "popup-container",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "popup-header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "popup-title",
					children: t.app_title
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "settings-btn",
					onClick: () => {
						if (typeof chrome !== "undefined" && chrome?.runtime?.openOptionsPage) chrome.runtime.openOptionsPage();
					},
					"aria-label": "Settings",
					title: "Settings",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 24 24",
						"aria-hidden": "true",
						className: "settings-icon",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 8.4a3.6 3.6 0 1 0 0 7.2 3.6 3.6 0 0 0 0-7.2Z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19.4 13.5c.1-.5.1-1 .1-1.5s0-1-.1-1.5l2-1.5-2-3.5-2.4 1a8.4 8.4 0 0 0-2.6-1.5L14 2.5h-4l-.4 2.5A8.4 8.4 0 0 0 7 6.5l-2.4-1-2 3.5 2 1.5c-.1.5-.1 1-.1 1.5s0 1 .1 1.5l-2 1.5 2 3.5 2.4-1a8.4 8.4 0 0 0 2.6 1.5l.4 2.5h4l.4-2.5a8.4 8.4 0 0 0 2.6-1.5l2.4 1 2-3.5-2-1.5Zm-7.4 4a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11Z" })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: "input-area",
				value: inputText,
				disabled: loading,
				onChange: (e) => setInputText(e.target.value),
				placeholder: t.input_placeholder,
				rows: 4
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "action-bar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "ask-btn",
					onClick: handleSubmit,
					disabled: loading,
					children: loading ? t.thinking : t.ask_ai
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: langWrapRef,
					className: "lang-wrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "lang-toggle",
						onClick: () => setLangMenuOpen(!langMenuOpen),
						children: language.toUpperCase()
					}), langMenuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lang-menu open",
						children: ["zh", "en"].map((lang) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `lang-option ${language === lang ? "active" : ""}`,
							onClick: () => {
								setLanguage(lang);
								setLangMenuOpen(false);
								setStorage({ lang });
							},
							children: lang.toUpperCase()
						}, lang))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "speed-bar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "speed-label",
					children: t.speed_label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "speed-toggle-group",
					children: ["fast", "detail"].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: `speed-btn ${speed === s ? "active" : ""}`,
						onClick: () => {
							setSpeed(s);
							setStorage({ explainSpeed: s });
						},
						children: t["speed_" + s]
					}, s))
				})]
			}),
			showResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "result-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "result-header",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "result-title",
						children: t.results_title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "result-header-right",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "result-close-btn",
							onClick: () => setShowResult(false),
							children: "✕"
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					result?.type === "loading" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSpinner, { text: t.thinking }),
					result?.type === "streaming" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultStreaming, { text: result.text || t.thinking }),
					result?.type === "error" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultError, { message: result.message }),
					result?.type === "success" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultSuccess, { html: result.html })
				] })]
			}),
			historyList.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "history-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "history-header",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "history-title",
						children: t.history_title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "clear-history-btn",
						onClick: () => {
							setHistoryList([]);
							setStorage({ history: [] });
						},
						children: t.clear_history
					})]
				}), historyList.slice(0, 5).map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryItem, {
					item,
					onClick: () => {
						setInputText(item.text);
						setLanguage(item.language || "zh");
						setSpeed(item.speed || "fast");
						explainText(item.text, item.language || "zh", item.speed || "fast");
					}
				}, i))]
			})
		]
	});
}
//#endregion
//#region src/popup/main.jsx
import_client.createRoot(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Popup, {}) }));
//#endregion
