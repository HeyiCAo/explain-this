import { c as require_react, i as normalizeUsageStats, l as __toESM, n as formatTokenCount, o as remainingTokens, r as getUsageStats, s as require_client, t as require_jsx_runtime } from "./jsx-runtime-BlGLasjB.js";
//#region src/settingStyle.css
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_client = /* @__PURE__ */ __toESM(require_client(), 1);
//#endregion
//#region src/settings/settings.jsx
var import_jsx_runtime = require_jsx_runtime();
var hasExtensionStorage = () => typeof chrome !== "undefined" && chrome?.storage?.local;
var getStorage = (keys) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve({});
		return;
	}
	chrome.storage.local.get(keys, resolve);
});
var setStorage = (values) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve();
		return;
	}
	chrome.storage.local.set(values, resolve);
});
var settingsZh = {
	settings: "设置",
	apiConfig: "API 配置",
	provider: "服务商：",
	deepseek: "DeepSeek",
	gemini: "Gemini",
	openai: "OpenAI",
	deepseekGuide: "DeepSeek API Key 获取指南",
	deepseekStep1: "1. 打开 DeepSeek 开放平台并登录/注册",
	deepseekStep2: "2. 进入 API Keys 页面创建新密钥",
	deepseekStep3: "3. 将密钥粘贴到下方",
	geminiGuide: "Gemini API Key 获取指南",
	geminiStep1: "1. 打开 Google AI Studio 的 API key 页面",
	geminiStep2: "2. 将密钥粘贴到下方",
	openaiGuide: "OpenAI API Key 获取指南",
	openaiStep1: "1. 打开 OpenAI Platform 的 API keys 页面",
	openaiStep2: "2. 创建新密钥并粘贴到下方",
	dataNotice: "数据说明",
	dataNoticeContent: "选中的文本将发送给您选择的 AI 服务商以生成解释。详见我们的隐私政策。",
	privacyPolicy: "隐私政策",
	openDeepseekPlatform: "打开 DeepSeek 平台",
	openDeepseekDocs: "查看 DeepSeek API 文档",
	openGeminiKeys: "打开 Gemini API Key 页面",
	openOpenAIKeys: "打开 OpenAI API Key 页面",
	openPrivacyPolicy: "查看隐私政策",
	apiKeyLabel: "API Key：",
	apiKeyPlaceholder: "sk-...",
	geminiKeyLabel: "Gemini API Key：",
	geminiKeyPlaceholder: "AIza...",
	openaiKeyLabel: "OpenAI API Key：",
	openaiKeyPlaceholder: "sk-...",
	saveKey: "保存密钥",
	testConnection: "测试连接",
	usageStats: "使用统计",
	todayUsage: "今日使用：",
	totalUsage: "累计使用：",
	creditRemaining: "估算剩余额度：",
	usageStatsNote: "按本地请求记录估算 token；真实账单请以服务商控制台为准。",
	hotkeySettings: "快捷键与操作方式",
	explainSelected: "解释选中内容：",
	close: "关闭",
	status_enter_key: "请输入API密钥。详情请查看设置页面。",
	status_invalid_key: "密钥格式无效",
	status_testing: "正在测试连接...",
	status_success: "连接成功！",
	status_invalid_retry: "密钥无效，请重试",
	status_conn_failed: "连接失败，请检查网络",
	mouseClick: "点击弹窗",
	mouseClickStep: "选词并点击后，AI搜索会自动开始。 "
};
var settingsEn = {
	settings: "Settings",
	apiConfig: "API Configurations",
	provider: "Provider:",
	deepseek: "DeepSeek",
	gemini: "Gemini",
	openai: "OpenAI",
	deepseekGuide: "DeepSeek API Key Required",
	deepseekStep1: "1. Open the DeepSeek platform and sign in or register",
	deepseekStep2: "2. Go to API Keys and create a new secret key",
	deepseekStep3: "3. Paste the key below",
	geminiGuide: "Gemini API Key Required",
	geminiStep1: "1. Open the Google AI Studio API key page",
	geminiStep2: "2. Paste the key below",
	openaiGuide: "OpenAI API Key Required",
	openaiStep1: "1. Open the OpenAI Platform API keys page",
	openaiStep2: "2. Create a new secret key and paste it below",
	dataNotice: "Data Notice",
	dataNoticeContent: "Selected text will be sent to your chosen AI provider to generate explanations. See our Privacy Policy.",
	privacyPolicy: "Privacy Policy",
	openDeepseekPlatform: "Open DeepSeek Platform",
	openDeepseekDocs: "View DeepSeek API Docs",
	openGeminiKeys: "Open Gemini API Key Page",
	openOpenAIKeys: "Open OpenAI API Key Page",
	openPrivacyPolicy: "View Privacy Policy",
	apiKeyLabel: "API Key:",
	apiKeyPlaceholder: "sk-...",
	geminiKeyLabel: "Gemini API Key:",
	geminiKeyPlaceholder: "AIza...",
	openaiKeyLabel: "OpenAI API Key:",
	openaiKeyPlaceholder: "sk-...",
	saveKey: "Save Key",
	testConnection: "Test Connection",
	usageStats: "Usage Statistics",
	todayUsage: "Today:",
	totalUsage: "Total:",
	creditRemaining: "Estimated remaining:",
	usageStatsNote: "Estimated from local request records. Provider dashboards remain the source of truth.",
	hotkeySettings: "Hotkeys and Manuals",
	explainSelected: "Explain Selected:",
	close: "Close",
	status_enter_key: "Please enter API key to begin searching. Visit settings page for more detail.",
	status_invalid_key: "Invalid API key format",
	status_testing: "Testing connection...",
	status_success: "Success!",
	status_invalid_retry: "Invalid API key. Try again.",
	status_conn_failed: "Connection failed. Check network.",
	mouseClick: "Click",
	mouseClickStep: "When clicking on the popup after text selection, search will automatically begin."
};
function InfoBox({ boxId, title, children, style }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "info-box",
		id: boxId,
		style,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: title }), children]
	});
}
function StatItem({ id, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stat-item",
		id,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "stat-label",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "stat-value",
			children
		})]
	});
}
function Section({ id, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "section",
		id,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-title",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: title })]
		}), children]
	});
}
function isMacPlatform() {
	return /Mac|iPhone|iPad|iPod/i.test(navigator.platform);
}
function LinkButton({ href, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		className: "guide-link",
		href,
		target: "_blank",
		rel: "noreferrer",
		children
	});
}
function SettingsPage() {
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [provider, setProvider] = (0, import_react.useState)("openai");
	const [lang, setLang] = (0, import_react.useState)("zh");
	const [status, setStatus] = (0, import_react.useState)({
		message: "",
		type: ""
	});
	const [usageStats, setUsageStats] = (0, import_react.useState)(normalizeUsageStats());
	const [apiKey, setApiKey] = (0, import_react.useState)("");
	const t = lang === "zh" ? settingsZh : settingsEn;
	const shortcutModifier = isMacPlatform() ? "Cmd" : "Ctrl";
	const privacyUrl = "https://github.com/HeyiCAo/ExplainThis/blob/main/privacy-policy.md";
	(0, import_react.useEffect)(() => {
		getStorage([
			"apiKey",
			"geminiApiKey",
			"openaiApiKey",
			"provider",
			"lang"
		]).then((result) => {
			const savedProvider = result.provider || "openai";
			setProvider(savedProvider);
			if (savedProvider === "gemini") setApiKey(result.geminiApiKey || "");
			else if (savedProvider === "openai") setApiKey(result.openaiApiKey || "");
			else setApiKey(result.apiKey || "");
			if (result.lang) setLang(result.lang);
		});
	}, []);
	(0, import_react.useEffect)(() => {
		getUsageStats().then(setUsageStats);
		if (typeof chrome === "undefined" || !chrome?.storage?.onChanged) return void 0;
		const handleStorageChange = (changes, areaName) => {
			if (areaName !== "local" || !changes.usageStats) return;
			setUsageStats(normalizeUsageStats(changes.usageStats.newValue));
		};
		chrome.storage.onChanged.addListener(handleStorageChange);
		return () => chrome.storage.onChanged.removeListener(handleStorageChange);
	}, []);
	(0, import_react.useEffect)(() => {
		setStorage({ lang });
	}, [lang]);
	function handleProviderChange(nextProvider) {
		setMenuOpen(false);
		setProvider(nextProvider);
		setStorage({ provider: nextProvider });
		getStorage([
			"apiKey",
			"geminiApiKey",
			"openaiApiKey"
		]).then((result) => {
			if (nextProvider === "gemini") setApiKey(result.geminiApiKey || "");
			else if (nextProvider === "openai") setApiKey(result.openaiApiKey || "");
			else setApiKey(result.apiKey || "");
		});
	}
	function handleClose() {
		if (typeof chrome !== "undefined" && chrome?.tabs?.getCurrent && chrome?.tabs?.remove) {
			chrome.tabs.getCurrent((tab) => {
				if (tab?.id) chrome.tabs.remove(tab.id);
				else window.close();
			});
			return;
		}
		window.close();
	}
	function handleSaveKey() {
		if (!apiKey.trim()) {
			setStatus({
				message: t.status_enter_key,
				type: "error"
			});
			return;
		}
		if (provider === "deepseek" && !apiKey.startsWith("sk-")) {
			setStatus({
				message: t.status_invalid_key,
				type: "error"
			});
			return;
		}
		if (provider === "gemini" && !apiKey.startsWith("AIza")) {
			setStatus({
				message: t.status_invalid_key,
				type: "error"
			});
			return;
		}
		if (provider === "openai" && !apiKey.startsWith("sk-")) {
			setStatus({
				message: t.status_invalid_key,
				type: "error"
			});
			return;
		}
		let keyPayload;
		if (provider === "gemini") keyPayload = {
			provider,
			geminiApiKey: apiKey
		};
		else if (provider === "openai") keyPayload = {
			provider,
			openaiApiKey: apiKey
		};
		else keyPayload = {
			provider,
			apiKey
		};
		setStorage(keyPayload);
		setStatus({
			message: t.status_success,
			type: "success"
		});
	}
	async function handleTestConnection() {
		if (provider === "deepseek") {
			if (!apiKey.startsWith("sk-")) {
				setStatus({
					message: t.status_enter_key,
					type: "error"
				});
				return;
			}
			setStatus({
				message: t.status_testing,
				type: "info"
			});
			try {
				if ((await fetch("https://api.deepseek.com/v1/models", { headers: { "Authorization": `Bearer ${apiKey}` } })).ok) setStatus({
					message: t.status_success,
					type: "success"
				});
				else setStatus({
					message: t.status_invalid_key,
					type: "error"
				});
			} catch {
				setStatus({
					message: t.status_invalid_retry,
					type: "error"
				});
			}
		} else if (provider === "gemini") {
			if (!apiKey.startsWith("AIza")) {
				setStatus({
					message: t.status_enter_key,
					type: "error"
				});
				return;
			}
			setStatus({
				message: t.status_testing,
				type: "info"
			});
			try {
				if ((await fetch("https://generativelanguage.googleapis.com/v1beta/models", { headers: { "x-goog-api-key": apiKey } })).ok) setStatus({
					message: t.status_success,
					type: "success"
				});
				else setStatus({
					message: t.status_invalid_key,
					type: "error"
				});
			} catch {
				setStatus({
					message: t.status_invalid_retry,
					type: "error"
				});
			}
		} else if (provider === "openai") {
			if (!apiKey.startsWith("sk-")) {
				setStatus({
					message: t.status_enter_key,
					type: "error"
				});
				return;
			}
			setStatus({
				message: t.status_testing,
				type: "info"
			});
			try {
				if ((await fetch("https://api.openai.com/v1/models", { headers: { "Authorization": `Bearer ${apiKey}` } })).ok) setStatus({
					message: t.status_success,
					type: "success"
				});
				else setStatus({
					message: t.status_invalid_key,
					type: "error"
				});
			} catch {
				setStatus({
					message: t.status_invalid_retry,
					type: "error"
				});
			}
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "top-bar",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.settings }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "top-actions",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "lang-switch",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setLang("zh"),
					className: lang === "zh" ? "active" : "",
					children: "中"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setLang("en"),
					className: lang === "en" ? "active" : "",
					children: "EN"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "close-btn",
				onClick: handleClose,
				children: t.close
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "section-grid",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
			id: "apiConfig",
			title: t.apiConfig,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: "providerToggle",
					children: t.provider
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "provider-wrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "provider-toggle",
						type: "button",
						"aria-haspopup": "listbox",
						onClick: () => setMenuOpen(!menuOpen),
						children: [provider === "deepseek" ? "DeepSeek" : provider === "gemini" ? "Gemini" : "OpenAI", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "▾" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `provider-menu${menuOpen ? " open" : ""}`,
						role: "listbox",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "provider-item",
								role: "option",
								onClick: () => handleProviderChange("deepseek"),
								children: "DeepSeek"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "provider-item",
								role: "option",
								onClick: () => handleProviderChange("gemini"),
								children: "Gemini"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "provider-item",
								role: "option",
								onClick: () => handleProviderChange("openai"),
								children: "OpenAI"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoBox, {
					title: t.deepseekGuide,
					style: { display: provider === "deepseek" ? "block" : "none" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						style: { margin: "10px 0 0 0" },
						children: [
							t.deepseekStep1,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							t.deepseekStep2,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							t.deepseekStep3,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "guide-links",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkButton, {
							href: "https://platform.deepseek.com/",
							children: t.openDeepseekPlatform
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkButton, {
							href: "https://api-docs.deepseek.com/",
							children: t.openDeepseekDocs
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoBox, {
					title: t.geminiGuide,
					style: { display: provider === "gemini" ? "block" : "none" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						style: { margin: "10px 0 0 0" },
						children: [
							t.geminiStep1,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							t.geminiStep2,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "guide-links",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkButton, {
							href: "https://aistudio.google.com/app/apikey",
							children: t.openGeminiKeys
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoBox, {
					title: t.openaiGuide,
					style: { display: provider === "openai" ? "block" : "none" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						style: { margin: "10px 0 0 0" },
						children: [
							t.openaiStep1,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							t.openaiStep2,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "guide-links",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkButton, {
							href: "https://platform.openai.com/api-keys",
							children: t.openOpenAIKeys
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoBox, {
					title: t.dataNotice,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						style: { margin: "8px 0 0 0" },
						children: t.dataNoticeContent
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "guide-links",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkButton, {
							href: privacyUrl,
							children: t.openPrivacyPolicy
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					style: { display: provider === "deepseek" ? "block" : "none" },
					children: t.apiKeyLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					placeholder: "sk-...",
					value: apiKey,
					style: { display: provider === "deepseek" ? "block" : "none" },
					onChange: (e) => setApiKey(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					style: { display: provider === "gemini" ? "block" : "none" },
					children: t.geminiKeyLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					placeholder: "AIza...",
					value: apiKey,
					style: { display: provider === "gemini" ? "block" : "none" },
					onChange: (e) => setApiKey(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					style: { display: provider === "openai" ? "block" : "none" },
					children: t.openaiKeyLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					placeholder: "sk-...",
					value: apiKey,
					style: { display: provider === "openai" ? "block" : "none" },
					onChange: (e) => setApiKey(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "button-group",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "primary-btn",
						onClick: handleSaveKey,
						children: t.saveKey
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "secondary-btn",
						onClick: handleTestConnection,
						children: t.testConnection
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `status ${status.type}`,
					children: status.message
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "right-column",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "usageStats",
				title: t.usageStats,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StatItem, {
						id: "todayUsage",
						title: t.todayUsage,
						children: [
							usageStats.todayRequests,
							" / ",
							formatTokenCount(usageStats.todayTokens)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StatItem, {
						id: "totalUsage",
						title: t.totalUsage,
						children: [
							usageStats.totalRequests,
							" / ",
							formatTokenCount(usageStats.totalTokens)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatItem, {
						id: "creditRemaining",
						title: t.creditRemaining,
						children: formatTokenCount(remainingTokens(usageStats))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "stats-note",
						children: t.usageStatsNote
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "hotkeySettings",
				title: t.hotkeySettings,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StatItem, {
					id: "explainSelected",
					title: t.explainSelected,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: shortcutModifier }),
						"+",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "E" })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatItem, {
					id: "explainSelected",
					title: t.mouseClick,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: t.mouseClickStep })
				})]
			})]
		})]
	})] });
}
//#endregion
//#region src/settings/main.jsx
import_client.createRoot(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPage, {}) }));
//#endregion
