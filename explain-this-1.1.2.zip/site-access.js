const ALL_SITE_ORIGINS = ['https://*/*', 'http://*/*'];

const copy = {
  zh: {
    eyebrow: 'Explain This 网站访问',
    title: '让划词气泡自动出现',
    intro: '授权一次后，Explain This 就能在普通网页上自动显示划词按钮，无需每次先点击扩展图标。',
    privacyTitle: '这个权限会做什么？',
    privacyBody: 'Chrome 会显示“读取和更改网站数据”的标准提示。扩展只在你选中文字时显示按钮，不会上传网页内容；只有你点击解释后，所选文字才会被处理。',
    allow: '允许在所有网站自动启用',
    allowing: '正在等待 Chrome 授权…',
    granted: '已启用。以后打开普通网页即可直接划词。',
    denied: '未获得授权，你仍可继续使用每页点击激活的模式。',
    skip: '暂时不用',
    continue: '继续设置',
    done: '完成',
  },
  en: {
    eyebrow: 'Explain This site access',
    title: 'Make the selection bubble appear automatically',
    intro: 'Grant access once and Explain This can show its selection button on regular websites without a toolbar click on every page.',
    privacyTitle: 'What does this permission do?',
    privacyBody: 'Chrome will show its standard “read and change site data” prompt. The extension only displays a button when you select text and does not upload page content. Only text you explicitly submit is processed.',
    allow: 'Enable automatically on all websites',
    allowing: 'Waiting for Chrome permission…',
    granted: 'Enabled. You can now highlight text directly on regular websites.',
    denied: 'Permission was not granted. You can still use click-to-activate mode.',
    skip: 'Not now',
    continue: 'Continue setup',
    done: 'Done',
  },
};

const allowButton = document.querySelector('#allowButton');
const continueButton = document.querySelector('#continueButton');
const status = document.querySelector('#status');
const isWelcome = new URLSearchParams(location.search).get('welcome') === '1';
let language = 'en';

function applyCopy() {
  const labels = copy[language];
  document.documentElement.lang = language === 'zh' ? 'zh-CN' : 'en';
  document.querySelectorAll('[data-copy]').forEach((element) => {
    const key = element.dataset.copy;
    if (labels[key]) element.textContent = labels[key];
  });
  continueButton.textContent = isWelcome ? labels.continue : labels.skip;
}

function continueFlow() {
  if (isWelcome) {
    location.href = chrome.runtime.getURL('popup.html?welcome=1');
    return;
  }
  window.close();
}

function setGrantedState() {
  const labels = copy[language];
  allowButton.disabled = true;
  allowButton.textContent = labels.granted;
  continueButton.textContent = isWelcome ? labels.continue : labels.done;
  status.textContent = labels.granted;
  status.className = 'status success';
}

allowButton.addEventListener('click', () => {
  const labels = copy[language];
  allowButton.disabled = true;
  allowButton.textContent = labels.allowing;
  status.textContent = labels.allowing;
  status.className = 'status';

  chrome.permissions.request({ origins: ALL_SITE_ORIGINS }, (granted) => {
    if (chrome.runtime.lastError || !granted) {
      allowButton.disabled = false;
      allowButton.textContent = labels.allow;
      status.textContent = labels.denied;
      status.className = 'status error';
      return;
    }

    chrome.storage.local.set({ allSitesEnabled: true }, () => {
      chrome.runtime.sendMessage({ action: 'syncEnabledSites' }, () => {
        void chrome.runtime.lastError;
        setGrantedState();
      });
    });
  });
});

continueButton.addEventListener('click', continueFlow);

chrome.storage.local.get(['lang'], (result) => {
  language = result.lang === 'zh' ? 'zh' : 'en';
  applyCopy();
  chrome.permissions.contains({ origins: ALL_SITE_ORIGINS }, (granted) => {
    if (granted) setGrantedState();
  });
});
