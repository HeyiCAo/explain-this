import { a as recordUsage, c as require_react, l as __toESM, s as require_client, t as require_jsx_runtime } from "./jsx-runtime-BlGLasjB.js";
//#region src/styles.css
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_client = /* @__PURE__ */ __toESM(require_client(), 1);
//#endregion
//#region src/shared/apiService.js
var AIService = class {
	constructor() {
		this.apiKey = null;
		this.provider = "openai";
		this.baseURL = "https://api.deepseek.com/v1";
		this.model = "deepseek-chat";
		this.geminiBaseURL = "https://generativelanguage.googleapis.com/v1beta";
		this.geminiModel = "gemini-3.5-flash";
		this.openaiBaseURL = "https://api.openai.com/v1";
		this.openaiModel = "gpt-5.4-mini";
	}
	async loadApiKey() {
		return new Promise((resolve) => {
			chrome.storage.local.get([
				"apiKey",
				"geminiApiKey",
				"openaiApiKey",
				"provider"
			], (result) => {
				this.provider = result.provider || "openai";
				if (this.provider === "gemini") this.apiKey = result.geminiApiKey || "";
				else if (this.provider === "openai") this.apiKey = result.openaiApiKey || "";
				else this.apiKey = result.apiKey || "";
				this.apiKey = String(this.apiKey).trim();
				resolve(this.apiKey);
			});
		});
	}
	async explainText(text, options = {}) {
		await this.loadApiKey();
		if (!this.apiKey) throw new Error("Please set up an API key first");
		const prompt = this.buildPrompt(text, options);
		const language = options.language || "zh";
		const isFast = (options.speed || "fast") === "fast";
		const systemContent = this.buildSystemContent(language, isFast);
		if (this.provider === "gemini") return this.explainWithGemini(prompt, isFast, systemContent);
		if (this.provider === "openai") return this.explainWithOpenAI(prompt, isFast, systemContent);
		const response = await fetch(`${this.baseURL}/chat/completions`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"Authorization": `Bearer ${this.apiKey}`
			},
			body: JSON.stringify({
				model: this.model,
				messages: [{
					role: "system",
					content: systemContent
				}, {
					role: "user",
					content: prompt
				}],
				max_tokens: isFast ? 800 : 2e3,
				temperature: isFast ? .1 : .4
			})
		});
		if (!response.ok) throw new Error(`API Call Failure (HTTP ${response.status}): ${await this.readError(response)}`);
		const data = await response.json();
		return this.formatExplanation(data.choices?.[0]?.message?.content || "");
	}
	async explainTextStream(text, options = {}, onChunk = () => {}) {
		await this.loadApiKey();
		if (!this.apiKey) throw new Error("Please set up an API key first");
		const prompt = this.buildPrompt(text, options);
		const language = options.language || "zh";
		const isFast = (options.speed || "fast") === "fast";
		const systemContent = this.buildSystemContent(language, isFast);
		if (this.provider === "gemini") return this.explainGeminiStream(prompt, isFast, systemContent, onChunk);
		if (this.provider === "openai") return this.explainOpenAIStream(prompt, isFast, systemContent, onChunk);
		const response = await fetch(`${this.baseURL}/chat/completions`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"Authorization": `Bearer ${this.apiKey}`
			},
			body: JSON.stringify({
				model: this.model,
				messages: [{
					role: "system",
					content: systemContent
				}, {
					role: "user",
					content: prompt
				}],
				max_tokens: isFast ? 800 : 2e3,
				temperature: isFast ? .1 : .4,
				stream: true
			})
		});
		if (!response.ok) throw new Error(`API Call Failure (HTTP ${response.status}): ${await this.readError(response)}`);
		const fullText = await this.readSseStream(response, (data) => {
			const delta = data.choices?.[0]?.delta?.content || "";
			if (delta) onChunk(delta);
			return delta;
		});
		return this.formatExplanation(fullText);
	}
	async explainOpenAIStream(prompt, isFast, systemContent, onChunk) {
		const response = await fetch(`${this.openaiBaseURL}/responses`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"Authorization": `Bearer ${this.apiKey}`
			},
			body: JSON.stringify({
				model: this.openaiModel,
				instructions: systemContent,
				input: prompt,
				max_output_tokens: isFast ? 800 : 2e3,
				stream: true
			})
		});
		if (!response.ok) throw new Error(`API Call Failure (HTTP ${response.status}): ${await this.readError(response)}`);
		const fullText = await this.readSseStream(response, (data) => {
			const delta = data.type === "response.output_text.delta" ? data.delta || "" : "";
			if (delta) onChunk(delta);
			return delta;
		});
		return this.formatExplanation(fullText);
	}
	async explainGeminiStream(prompt, isFast, systemContent, onChunk) {
		const response = await fetch(`${this.geminiBaseURL}/models/${this.geminiModel}:streamGenerateContent?alt=sse`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"x-goog-api-key": this.apiKey
			},
			body: JSON.stringify({
				system_instruction: { parts: [{ text: systemContent }] },
				contents: [{
					role: "user",
					parts: [{ text: prompt }]
				}],
				generationConfig: {
					maxOutputTokens: isFast ? 800 : 2e3,
					temperature: isFast ? .1 : .4
				}
			})
		});
		if (!response.ok) throw new Error(`API Call Failure (HTTP ${response.status}): ${await this.readError(response)}`);
		const fullText = await this.readSseStream(response, (data) => {
			const delta = (data.candidates?.[0]?.content?.parts || []).map((part) => part.text || "").join("");
			if (delta) onChunk(delta);
			return delta;
		});
		return this.formatExplanation(fullText);
	}
	async readSseStream(response, extractDelta) {
		const reader = response.body?.getReader();
		if (!reader) throw new Error("Streaming response is not supported in this browser");
		const decoder = new TextDecoder();
		let buffer = "";
		let fullText = "";
		while (true) {
			const { value, done } = await reader.read();
			if (done) break;
			buffer += decoder.decode(value, { stream: true });
			const lines = buffer.split(/\r?\n/);
			buffer = lines.pop() || "";
			for (const line of lines) {
				const trimmed = line.trim();
				if (!trimmed.startsWith("data:")) continue;
				const payload = trimmed.slice(5).trim();
				if (!payload || payload === "[DONE]") continue;
				try {
					const delta = extractDelta(JSON.parse(payload));
					fullText += delta || "";
				} catch (error) {
					console.warn("Failed to parse stream chunk", error);
				}
			}
		}
		return fullText;
	}
	buildSystemContent(language, isFast) {
		return `${isFast ? language === "en" ? "You are a highly concise dictionary assistant. Provide ONLY a single short paragraph (maximum 3 sentences) summarizing the core meaning. Do NOT output any bullet points, lists, examples, or extra details." : "你是一个极简词典助手。请仅用一段简短的话（最多3句话）总结核心含义。绝不能输出任何列表、要点、例子或多余细节，说完即止。" : language === "en" ? "You are a professional explainer. Use simple language and include helpful examples." : "你是一个专业的解释助手。请用简单易懂的语言详细解释用户输入的内容。"}
${!isFast ? language === "en" ? "Format: first give a one-sentence summary, then explain in bullets, then include a relevant example." : "格式要求：1. 第一行用一句话总结 2. 然后分点详细解释 3. 最后给出相关例子" : ""}
${language === "en" ? "Use English for the entire response." : "请全程使用中文回答。"}`;
	}
	async explainWithGemini(prompt, isFast, systemContent) {
		const response = await fetch(`${this.geminiBaseURL}/models/${this.geminiModel}:generateContent`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"x-goog-api-key": this.apiKey
			},
			body: JSON.stringify({
				system_instruction: { parts: [{ text: systemContent }] },
				contents: [{
					role: "user",
					parts: [{ text: prompt }]
				}],
				generationConfig: {
					maxOutputTokens: isFast ? 800 : 2e3,
					temperature: isFast ? .1 : .4
				}
			})
		});
		if (!response.ok) throw new Error(`API Call Failure (HTTP ${response.status}): ${await this.readError(response)}`);
		const text = ((await response.json()).candidates?.[0]?.content?.parts || []).map((part) => part.text || "").join("");
		return this.formatExplanation(text);
	}
	async explainWithOpenAI(prompt, isFast, systemContent) {
		const response = await fetch(`${this.openaiBaseURL}/responses`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"Authorization": `Bearer ${this.apiKey}`
			},
			body: JSON.stringify({
				model: this.openaiModel,
				instructions: systemContent,
				input: prompt,
				max_output_tokens: isFast ? 800 : 2e3
			})
		});
		if (!response.ok) throw new Error(`API Call Failure (HTTP ${response.status}): ${await this.readError(response)}`);
		const data = await response.json();
		return this.formatExplanation(this.extractOpenAIText(data));
	}
	extractOpenAIText(data) {
		if (data.output_text) return data.output_text;
		return (data.output || []).flatMap((item) => item.content || []).map((content) => content.text || "").join("");
	}
	async readError(response) {
		try {
			return JSON.stringify(await response.json());
		} catch {
			return response.text();
		}
	}
	buildPrompt(text, options) {
		let prompt = `${(options.language || "zh") === "en" ? "Explain:" : "请解释："}${text}`;
		if (options.context) prompt += `\n上下文：${options.context}`;
		return prompt;
	}
	formatExplanation(explanation) {
		const html = this.escapeHtml(explanation).replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>").replace(/\*(.*?)\*/g, "<em>$1</em>").replace(/`(.*?)`/g, "<code>$1</code>").replace(/\n/g, "<br>");
		return this.sanitizeHtml(this.renderMath(html));
	}
	escapeHtml(text) {
		return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
	}
	sanitizeHtml(html) {
		const allowedTags = new Set([
			"strong",
			"em",
			"code",
			"br",
			"span",
			"div",
			"sub",
			"sup"
		]);
		const allowedClass = new Set([
			"math-inline",
			"math-display",
			"frac",
			"num",
			"den",
			"op"
		]);
		const template = document.createElement("template");
		template.innerHTML = html;
		const walk = (node) => {
			Array.from(node.childNodes).forEach((child) => {
				if (child.nodeType !== Node.ELEMENT_NODE) return;
				const tag = child.tagName.toLowerCase();
				if (!allowedTags.has(tag)) {
					child.replaceWith(document.createTextNode(child.textContent || ""));
					return;
				}
				Array.from(child.attributes).forEach((attr) => {
					if (attr.name === "class") {
						const classes = attr.value.split(/\s+/).filter((className) => allowedClass.has(className));
						classes.length ? child.setAttribute("class", classes.join(" ")) : child.removeAttribute("class");
					} else child.removeAttribute(attr.name);
				});
				walk(child);
			});
		};
		walk(template.content);
		return template.innerHTML;
	}
	renderMath(html) {
		let out = html;
		out = out.replace(/\\\[((?:.|\n)*?)\\\]/g, (match, content) => {
			return `<div class="math-display">${this.latexToHtml(content)}</div>`;
		});
		out = out.replace(/\\\((.*?)\\\)/g, (match, content) => {
			return `<span class="math-inline">${this.latexToHtml(content)}</span>`;
		});
		return out;
	}
	latexToHtml(latex) {
		if (!latex) return "";
		let s = latex;
		s = s.replace(/\\Delta/g, "Δ").replace(/\\to/g, "→").replace(/\\infty/g, "∞").replace(/\\cdot/g, "·").replace(/\\times/g, "×").replace(/\\leq/g, "≤").replace(/\\geq/g, "≥");
		for (let i = 0; i < 3; i += 1) s = s.replace(/\\frac\{([^{}]+)\}\{([^{}]+)\}/g, (match, a, b) => {
			return `<span class="frac"><span class="num">${a}</span><span class="den">${b}</span></span>`;
		});
		s = s.replace(/_({[^}]+}|[^\s^_])/g, (match) => {
			return `<sub>${match.slice(1).replace(/^\{|\}$/g, "")}</sub>`;
		});
		s = s.replace(/\^({[^}]+}|[^\s^_])/g, (match) => {
			return `<sup>${match.slice(1).replace(/^\{|\}$/g, "")}</sup>`;
		});
		s = s.replace(/\\lim<sub>(.*?)<\/sub>/g, (match, sub) => `<span class="op">lim</span><sub>${sub}</sub>`);
		return s.replace(/\\lim/g, "<span class=\"op\">lim</span>");
	}
};
//#endregion
//#region src/popup/popup.jsx
var import_jsx_runtime = require_jsx_runtime();
var hasExtensionStorage = () => typeof chrome !== "undefined" && chrome?.storage?.local;
var getStorage = (keys) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve({});
		return;
	}
	chrome.storage.local.get(keys, resolve);
});
var setStorage = (values) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve();
		return;
	}
	chrome.storage.local.set(values, resolve);
});
var popupZh = {
	app_title: "Explain This",
	input_placeholder: "粘贴或输入你不懂的内容...\n例如：'内卷是什么意思？'\n      'Python中的装饰器怎么理解？'\n      '这个历史典故有什么背景？'",
	ask_ai: "发送",
	speed_label: "速度",
	speed_fast: "快",
	speed_detail: "详",
	results_title: "结果",
	thinking: "思考中...",
	history_title: "最近记录",
	clear_history: "清空",
	empty_input: "请输入要解释的内容",
	api_error_prefix: "解释失败：",
	retry: "重试"
};
var popupEn = {
	app_title: "Explain This",
	input_placeholder: "Paste or type what you don't understand...",
	ask_ai: "Ask",
	speed_label: "Speed",
	speed_fast: "Fast",
	speed_detail: "Detail",
	results_title: "Results",
	thinking: "Thinking...",
	history_title: "Recent",
	clear_history: "Clear",
	empty_input: "Please enter text to explain",
	api_error_prefix: "Failed to explain: ",
	retry: "Try Again"
};
var onboardingZh = {
	eyebrow: "欢迎使用 Explain This",
	step: "第 {current} 步，共 4 步",
	back: "返回",
	continue: "继续",
	languageTitle: "选择你的使用语言",
	languageBody: "这会决定界面和 AI 回答的默认语言，之后仍可随时切换。",
	chinese: "中文",
	chineseHint: "使用中文界面和回答",
	english: "English",
	englishHint: "Use the app and AI in English",
	noticeTitle: "使用前，请了解 API Key",
	principleTitle: "它是怎么工作的？",
	principleBody: "扩展会把文本交给 AI 服务商处理；API Key 用来识别并授权你的账户。",
	principleAnalogy: "打个比方：就像刷自己的门卡请前台办事——扩展负责传话，服务商真正处理请求，Key 决定服务记到谁的账户。",
	noticePrivacyTitle: "会发送什么？",
	noticePrivacyBody: "你要求解释的文本会发送给所选服务商。请勿提交密码、密钥或其他敏感信息。",
	noticeRiskTitle: "你需要承担什么？",
	noticeRiskBody: "你需要负责保管 Key、服务商账户的使用和相关费用；如果 Key 泄露，请立即撤销。",
	localKeyNote: "Key 只保存在此浏览器的本地扩展存储中。",
	privacyPolicy: "查看隐私政策",
	agree: "我已了解并同意继续",
	providerTitle: "选择 AI 服务商",
	providerBody: "选择你已经拥有账户或准备申请 API Key 的服务商。",
	recommended: "推荐",
	freeAvailable: "可用免费",
	providerOpenAI: "通用且稳定，适合大多数内容",
	providerGemini: "Google 的生成式 AI 服务",
	providerDeepSeek: "中文体验好，价格较低",
	keyTitle: "连接 {provider}",
	keyBody: "粘贴你的 API Key。你可以先测试，确认无误后保存并开始使用。",
	keyLabel: "{provider} API Key",
	keyPlaceholder: "在这里粘贴 API Key",
	getKey: "获取 {provider} API Key",
	test: "测试连接",
	testing: "正在测试…",
	save: "保存并开始使用",
	saving: "正在保存…",
	enterKey: "请先输入 API Key",
	testSuccess: "连接成功，可以开始使用。",
	saved: "设置已保存。",
	connectionFailed: "连接失败"
};
var onboardingEn = {
	eyebrow: "Welcome to Explain This",
	step: "Step {current} of 4",
	back: "Back",
	continue: "Continue",
	languageTitle: "Choose your language",
	languageBody: "This sets the default language for the interface and AI responses. You can change it later.",
	chinese: "中文",
	chineseHint: "使用中文界面和回答",
	english: "English",
	englishHint: "Use the app and AI in English",
	noticeTitle: "Before you begin: API Keys",
	principleTitle: "How does it work?",
	principleBody: "The extension sends text to an AI provider. Your API Key identifies and authorizes your account.",
	principleAnalogy: "Think of a hotel concierge: the extension passes on your request, the provider does the work, and the key says which account receives the service.",
	noticePrivacyTitle: "What is sent?",
	noticePrivacyBody: "Your text goes to the selected provider. Never submit passwords, keys, or sensitive data.",
	noticeRiskTitle: "What are you responsible for?",
	noticeRiskBody: "You are responsible for your key, provider usage, and charges. Revoke a leaked key immediately.",
	localKeyNote: "Your key is stored only in this browser’s local extension storage.",
	privacyPolicy: "Read the Privacy Policy",
	agree: "I understand and agree to continue",
	providerTitle: "Choose an AI provider",
	providerBody: "Pick a provider where you already have an account or plan to create an API Key.",
	recommended: "Recommended",
	freeAvailable: "Free tier",
	providerOpenAI: "Reliable general-purpose explanations",
	providerGemini: "Google’s generative AI service",
	providerDeepSeek: "Strong Chinese support at a lower cost",
	keyTitle: "Connect {provider}",
	keyBody: "Paste your API Key. You can test it first, then save it and start using Explain This.",
	keyLabel: "{provider} API Key",
	keyPlaceholder: "Paste your API Key here",
	getKey: "Get a {provider} API Key",
	test: "Test connection",
	testing: "Testing…",
	save: "Save and start",
	saving: "Saving…",
	enterKey: "Enter an API Key first",
	testSuccess: "Connection successful. You’re ready to go.",
	saved: "Setup saved.",
	connectionFailed: "Connection failed"
};
var providerOptions = [
	{
		id: "openai",
		name: "OpenAI",
		descriptionKey: "providerOpenAI",
		keyUrl: "https://platform.openai.com/api-keys",
		recommended: true
	},
	{
		id: "gemini",
		name: "Gemini",
		descriptionKey: "providerGemini",
		keyUrl: "https://aistudio.google.com/app/apikey",
		freeAvailable: true
	},
	{
		id: "deepseek",
		name: "DeepSeek",
		descriptionKey: "providerDeepSeek",
		keyUrl: "https://platform.deepseek.com/api_keys"
	}
];
var formatOnboardingText = (text, values) => Object.entries(values).reduce((result, [key, value]) => result.replace(`{${key}}`, value), text);
async function testProviderConnection(provider, apiKey) {
	let response;
	if (provider === "gemini") response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"x-goog-api-key": apiKey
		},
		body: JSON.stringify({
			contents: [{
				role: "user",
				parts: [{ text: "Reply with OK." }]
			}],
			generationConfig: {
				maxOutputTokens: 32,
				temperature: 0
			}
		})
	});
	else response = await fetch(provider === "openai" ? "https://api.openai.com/v1/models" : "https://api.deepseek.com/v1/models", { headers: { Authorization: `Bearer ${apiKey}` } });
	if (response.ok) return;
	const rawBody = await response.text();
	let details = rawBody || response.statusText;
	try {
		details = JSON.parse(rawBody)?.error?.message || details;
	} catch {}
	throw new Error(`HTTP ${response.status}${details ? `: ${details}` : ""}`);
}
function useSimpleCache() {
	const cacheRef = (0, import_react.useRef)({});
	(0, import_react.useEffect)(() => {
		getStorage(["explainCache"]).then((result) => {
			const list = result.explainCache || [];
			const newCache = { ...cacheRef.current };
			list.forEach((item) => {
				if (item && item.key) newCache[item.key] = item;
			});
			cacheRef.current = newCache;
		});
	}, []);
	const normalizeKey = (text, language, speed) => {
		const base = text.trim();
		if (!language) return base;
		if (!speed) return `${base}::${language}`;
		return `${base}::${language}::${speed}`;
	};
	return {
		getCache: (0, import_react.useCallback)((text, language, speed) => {
			const key = normalizeKey(text, language, speed);
			return cacheRef.current[key] || null;
		}, []),
		upsertCache: (0, import_react.useCallback)((text, explanation, language, speed) => {
			const key = normalizeKey(text, language, speed);
			cacheRef.current[key] = {
				key,
				text: text.substring(0, 200),
				explanation,
				language,
				speed,
				updatedAt: Date.now()
			};
			getStorage(["explainCache"]).then((result) => {
				const list = result.explainCache || [];
				setStorage({ explainCache: [cacheRef.current[key], ...list.filter((i) => i.key !== key)].slice(0, 100) });
			});
		}, [])
	};
}
function HistoryItem({ item, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "history-item",
		onClick,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "history-item-text",
			children: item.text
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "history-item-meta",
			children: [
				(item.language || "zh").toUpperCase(),
				" · ",
				item.timestamp
			]
		})]
	});
}
function LoadingSpinner({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "loading-container",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "spinner" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "loading-text",
			children: text
		})]
	});
}
function ResultError({ message }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "result-error",
		children: message
	});
}
function ResultSuccess({ html }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		id: "resultContent",
		className: "result-content",
		dangerouslySetInnerHTML: { __html: html }
	});
}
function ResultStreaming({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stream-container",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "stream-content",
			children: text
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "stream-cursor",
			children: "▊"
		})]
	});
}
function WelcomeFlow({ language, initialProvider, onLanguageChange, onComplete }) {
	const [step, setStep] = (0, import_react.useState)(1);
	const [provider, setProvider] = (0, import_react.useState)(initialProvider || "openai");
	const [apiKey, setApiKey] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)({
		message: "",
		type: ""
	});
	const [testing, setTesting] = (0, import_react.useState)(false);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const t = language === "zh" ? onboardingZh : onboardingEn;
	const selectedProvider = providerOptions.find((option) => option.id === provider) || providerOptions[0];
	const privacyUrl = "https://github.com/HeyiCAo/ExplainThis/blob/main/privacy-policy.md";
	const goToStep = (nextStep) => {
		setStatus({
			message: "",
			type: ""
		});
		setStep(nextStep);
	};
	const handleTest = async () => {
		const normalizedKey = apiKey.trim();
		if (!normalizedKey) {
			setStatus({
				message: t.enterKey,
				type: "error"
			});
			return;
		}
		setTesting(true);
		setStatus({
			message: "",
			type: ""
		});
		try {
			await testProviderConnection(provider, normalizedKey);
			setStatus({
				message: t.testSuccess,
				type: "success"
			});
		} catch (error) {
			setStatus({
				message: `${t.connectionFailed}: ${error.message}`,
				type: "error"
			});
		} finally {
			setTesting(false);
		}
	};
	const handleSave = async () => {
		const normalizedKey = apiKey.trim();
		if (!normalizedKey) {
			setStatus({
				message: t.enterKey,
				type: "error"
			});
			return;
		}
		const keyPayload = provider === "gemini" ? { geminiApiKey: normalizedKey } : provider === "openai" ? { openaiApiKey: normalizedKey } : { apiKey: normalizedKey };
		setSaving(true);
		await setStorage({
			...keyPayload,
			provider,
			lang: language,
			onboardingComplete: true
		});
		setStatus({
			message: t.saved,
			type: "success"
		});
		setSaving(false);
		onComplete();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: `welcome-container step-${step}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "welcome-topline",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "welcome-brand",
					children: t.eyebrow
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "welcome-step",
					children: formatOnboardingText(t.step, { current: step })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "welcome-progress",
				"aria-hidden": "true",
				children: [
					1,
					2,
					3,
					4
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: item <= step ? "active" : "" }, item))
			}),
			step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "welcome-page",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "welcome-icon",
						"aria-hidden": "true",
						children: "文"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: t.languageTitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "welcome-intro",
						children: t.languageBody
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "welcome-choice-list",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: `welcome-choice ${language === "zh" ? "selected" : ""}`,
							onClick: () => onLanguageChange("zh"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "welcome-choice-mark",
									children: "中"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.chinese }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t.chineseHint })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "welcome-radio",
									"aria-hidden": "true"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: `welcome-choice ${language === "en" ? "selected" : ""}`,
							onClick: () => onLanguageChange("en"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "welcome-choice-mark",
									children: "A"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.english }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t.englishHint })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "welcome-radio",
									"aria-hidden": "true"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "welcome-actions single",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "welcome-primary",
							onClick: () => goToStep(2),
							children: t.continue
						})
					})
				]
			}),
			step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "welcome-page notice-page",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "welcome-icon notice",
						"aria-hidden": "true",
						children: "!"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: t.noticeTitle }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "principle-box",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.principleTitle }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.principleBody }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "principle-analogy",
								children: t.principleAnalogy
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "notice-list",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: "↗"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.noticePrivacyTitle }), t.noticePrivacyBody] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: "◇"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.noticeRiskTitle }), t.noticeRiskBody] })] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "local-key-note",
						children: t.localKeyNote
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "welcome-link",
						href: privacyUrl,
						target: "_blank",
						rel: "noreferrer",
						children: [t.privacyPolicy, " ↗"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "welcome-actions",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "welcome-secondary",
							onClick: () => goToStep(1),
							children: t.back
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "welcome-primary",
							onClick: () => goToStep(3),
							children: t.agree
						})]
					})
				]
			}),
			step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "welcome-page",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "welcome-icon",
						"aria-hidden": "true",
						children: "AI"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: t.providerTitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "welcome-intro",
						children: t.providerBody
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "provider-choice-list",
						children: providerOptions.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: `provider-choice ${provider === option.id ? "selected" : ""}`,
							onClick: () => {
								if (option.id !== provider) setApiKey("");
								setProvider(option.id);
								setStatus({
									message: "",
									type: ""
								});
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `provider-logo ${option.id}`,
									children: option.name.charAt(0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
									option.name,
									option.recommended && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: t.recommended }),
									option.freeAvailable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
										className: "free-badge",
										children: t.freeAvailable
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t[option.descriptionKey] })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "welcome-radio",
									"aria-hidden": "true"
								})
							]
						}, option.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "welcome-actions",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "welcome-secondary",
							onClick: () => goToStep(2),
							children: t.back
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "welcome-primary",
							onClick: () => goToStep(4),
							children: t.continue
						})]
					})
				]
			}),
			step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "welcome-page",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `welcome-icon provider ${provider}`,
						"aria-hidden": "true",
						children: selectedProvider.name.charAt(0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: formatOnboardingText(t.keyTitle, { provider: selectedProvider.name }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "welcome-intro",
						children: t.keyBody
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "welcome-key-field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatOnboardingText(t.keyLabel, { provider: selectedProvider.name }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "password",
							value: apiKey,
							onChange: (event) => {
								setApiKey(event.target.value);
								setStatus({
									message: "",
									type: ""
								});
							},
							placeholder: t.keyPlaceholder,
							autoComplete: "off",
							spellCheck: "false"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "welcome-key-meta",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							className: "welcome-link",
							href: selectedProvider.keyUrl,
							target: "_blank",
							rel: "noreferrer",
							children: [formatOnboardingText(t.getKey, { provider: selectedProvider.name }), " ↗"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.localKeyNote })]
					}),
					status.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `welcome-status ${status.type}`,
						role: "status",
						children: status.message
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "welcome-actions key-actions",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "welcome-secondary back-only",
								onClick: () => goToStep(3),
								children: t.back
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "welcome-secondary",
								onClick: handleTest,
								disabled: testing || saving,
								children: testing ? t.testing : t.test
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "welcome-primary",
								onClick: handleSave,
								disabled: testing || saving,
								children: saving ? t.saving : t.save
							})
						]
					})
				]
			})
		]
	});
}
function Popup() {
	const [inputText, setInputText] = (0, import_react.useState)("");
	const [language, setLanguage] = (0, import_react.useState)("en");
	const [speed, setSpeed] = (0, import_react.useState)("fast");
	const [result, setResult] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [showResult, setShowResult] = (0, import_react.useState)(false);
	const [historyList, setHistoryList] = (0, import_react.useState)([]);
	const [langMenuOpen, setLangMenuOpen] = (0, import_react.useState)(false);
	const [onboardingRequired, setOnboardingRequired] = (0, import_react.useState)(null);
	const [initialProvider, setInitialProvider] = (0, import_react.useState)("openai");
	const langWrapRef = (0, import_react.useRef)(null);
	const aiServiceRef = (0, import_react.useRef)(new AIService());
	const { getCache, upsertCache } = useSimpleCache();
	const t = language === "zh" ? popupZh : popupEn;
	(0, import_react.useEffect)(() => {
		getStorage([
			"lang",
			"explainSpeed",
			"history",
			"lastSelectedText",
			"shouldAutoFill",
			"onboardingComplete",
			"provider",
			"apiKey",
			"geminiApiKey",
			"openaiApiKey"
		]).then((result) => {
			let currentLang = language;
			let currentSpeed = speed;
			const hasSavedKey = [
				result.apiKey,
				result.geminiApiKey,
				result.openaiApiKey
			].some((key) => String(key || "").trim());
			const setupComplete = result.onboardingComplete === true || hasSavedKey;
			if (result.lang) {
				setLanguage(result.lang);
				currentLang = result.lang;
			}
			if (result.explainSpeed) {
				setSpeed(result.explainSpeed);
				currentSpeed = result.explainSpeed;
			}
			if (result.history) setHistoryList(result.history);
			if (result.provider) setInitialProvider(result.provider);
			setOnboardingRequired(!setupComplete);
			if (hasSavedKey && result.onboardingComplete !== true) setStorage({ onboardingComplete: true });
			if (setupComplete && result.shouldAutoFill && result.lastSelectedText) {
				const text = result.lastSelectedText;
				setInputText(text);
				setLoading(true);
				setShowResult(true);
				setResult({
					type: "streaming",
					text: ""
				});
				aiServiceRef.current.explainTextStream(text, {
					language: currentLang,
					speed: currentSpeed
				}, (chunk) => {
					setResult((prev) => ({
						type: "streaming",
						text: (prev.text || "") + chunk
					}));
				}).then((html) => {
					setResult({
						type: "success",
						html
					});
					recordUsage({
						inputText: text,
						outputText: html.replace(/<[^>]+>/g, "")
					});
					upsertCache(text, html, currentLang, currentSpeed);
					setHistoryList((currentHistory) => {
						const newHistory = [{
							key: text,
							text: text.substring(0, 50),
							timestamp: (/* @__PURE__ */ new Date()).toLocaleString(),
							language: currentLang,
							speed: currentSpeed
						}, ...currentHistory.filter((h) => h.key !== text)].slice(0, 10);
						setStorage({ history: newHistory });
						return newHistory;
					});
				}).catch((error) => {
					setResult({
						type: "error",
						message: `${(currentLang === "zh" ? popupZh : popupEn).api_error_prefix}${error.message}`
					});
				}).finally(() => {
					setLoading(false);
					setStorage({
						shouldAutoFill: false,
						lastSelectedText: ""
					});
				});
			}
		});
	}, []);
	(0, import_react.useEffect)(() => {
		if (!langMenuOpen) return;
		const handler = (e) => {
			if (langWrapRef.current && !langWrapRef.current.contains(e.target)) setLangMenuOpen(false);
		};
		document.addEventListener("click", handler);
		return () => document.removeEventListener("click", handler);
	}, [langMenuOpen]);
	const explainText = (0, import_react.useCallback)(async (rawText, overrideLang, overrideSpeed) => {
		const text = rawText.trim();
		if (!text) {
			setResult({
				type: "error",
				message: t.empty_input
			});
			setShowResult(true);
			return;
		}
		const currentLang = overrideLang || language;
		const currentSpeed = overrideSpeed || speed;
		const cached = getCache(text, currentLang, currentSpeed);
		if (cached?.explanation) {
			setResult({
				type: "success",
				html: cached.explanation
			});
			setShowResult(true);
			return;
		}
		setLoading(true);
		setShowResult(true);
		setResult({
			type: "streaming",
			text: ""
		});
		try {
			let streamedText = "";
			const html = await aiServiceRef.current.explainTextStream(text, {
				language: currentLang,
				speed: currentSpeed
			}, (chunk) => {
				streamedText += chunk;
				setResult({
					type: "streaming",
					text: streamedText
				});
			});
			setResult({
				type: "success",
				html
			});
			recordUsage({
				inputText: text,
				outputText: streamedText
			});
			upsertCache(text, html, currentLang, currentSpeed);
			setHistoryList((currentHistory) => {
				const newHistory = [{
					key: text,
					text: text.substring(0, 50),
					timestamp: (/* @__PURE__ */ new Date()).toLocaleString(),
					language: currentLang,
					speed: currentSpeed
				}, ...currentHistory.filter((h) => h.key !== text)].slice(0, 10);
				setStorage({ history: newHistory });
				return newHistory;
			});
		} catch (error) {
			setResult({
				type: "error",
				message: `${t.api_error_prefix}${error.message}`
			});
		} finally {
			setLoading(false);
		}
	}, [
		language,
		speed,
		getCache,
		upsertCache,
		t
	]);
	const handleSubmit = (0, import_react.useCallback)(() => {
		explainText(inputText);
	}, [inputText, explainText]);
	if (onboardingRequired === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "popup-initializing",
		"aria-label": "Loading"
	});
	if (onboardingRequired) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WelcomeFlow, {
		language,
		initialProvider,
		onLanguageChange: (nextLanguage) => {
			setLanguage(nextLanguage);
			setStorage({ lang: nextLanguage });
		},
		onComplete: () => setOnboardingRequired(false)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "popup-container",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "popup-header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "popup-title",
					children: t.app_title
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "settings-btn",
					onClick: () => {
						if (typeof chrome !== "undefined" && chrome?.runtime?.openOptionsPage) chrome.runtime.openOptionsPage();
					},
					"aria-label": "Settings",
					title: "Settings",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 24 24",
						"aria-hidden": "true",
						className: "settings-icon",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 8.4a3.6 3.6 0 1 0 0 7.2 3.6 3.6 0 0 0 0-7.2Z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19.4 13.5c.1-.5.1-1 .1-1.5s0-1-.1-1.5l2-1.5-2-3.5-2.4 1a8.4 8.4 0 0 0-2.6-1.5L14 2.5h-4l-.4 2.5A8.4 8.4 0 0 0 7 6.5l-2.4-1-2 3.5 2 1.5c-.1.5-.1 1-.1 1.5s0 1 .1 1.5l-2 1.5 2 3.5 2.4-1a8.4 8.4 0 0 0 2.6 1.5l.4 2.5h4l.4-2.5a8.4 8.4 0 0 0 2.6-1.5l2.4 1 2-3.5-2-1.5Zm-7.4 4a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11Z" })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: "input-area",
				value: inputText,
				disabled: loading,
				onChange: (e) => setInputText(e.target.value),
				placeholder: t.input_placeholder,
				rows: 4
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "action-bar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "ask-btn",
					onClick: handleSubmit,
					disabled: loading,
					children: loading ? t.thinking : t.ask_ai
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: langWrapRef,
					className: "lang-wrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "lang-toggle",
						onClick: () => setLangMenuOpen(!langMenuOpen),
						children: language.toUpperCase()
					}), langMenuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lang-menu open",
						children: ["zh", "en"].map((lang) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `lang-option ${language === lang ? "active" : ""}`,
							onClick: () => {
								setLanguage(lang);
								setLangMenuOpen(false);
								setStorage({ lang });
							},
							children: lang.toUpperCase()
						}, lang))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "speed-bar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "speed-label",
					children: t.speed_label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "speed-toggle-group",
					children: ["fast", "detail"].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: `speed-btn ${speed === s ? "active" : ""}`,
						onClick: () => {
							setSpeed(s);
							setStorage({ explainSpeed: s });
						},
						children: t["speed_" + s]
					}, s))
				})]
			}),
			showResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "result-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "result-header",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "result-title",
						children: t.results_title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "result-header-right",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "result-close-btn",
							onClick: () => setShowResult(false),
							children: "✕"
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					result?.type === "loading" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSpinner, { text: t.thinking }),
					result?.type === "streaming" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultStreaming, { text: result.text || t.thinking }),
					result?.type === "error" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultError, { message: result.message }),
					result?.type === "success" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultSuccess, { html: result.html })
				] })]
			}),
			historyList.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "history-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "history-header",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "history-title",
						children: t.history_title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "clear-history-btn",
						onClick: () => {
							setHistoryList([]);
							setStorage({ history: [] });
						},
						children: t.clear_history
					})]
				}), historyList.slice(0, 5).map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryItem, {
					item,
					onClick: () => {
						setInputText(item.text);
						setLanguage(item.language || "zh");
						setSpeed(item.speed || "fast");
						explainText(item.text, item.language || "zh", item.speed || "fast");
					}
				}, i))]
			})
		]
	});
}
//#endregion
//#region src/popup/main.jsx
import_client.createRoot(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Popup, {}) }));
//#endregion
