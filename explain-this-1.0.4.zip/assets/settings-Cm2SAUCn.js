import { c as require_react, i as normalizeUsageStats, l as __toESM, n as formatTokenCount, o as remainingTokens, r as getUsageStats, s as require_client, t as require_jsx_runtime } from "./jsx-runtime-BlGLasjB.js";
//#region src/settingStyle.css
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_client = /* @__PURE__ */ __toESM(require_client(), 1);
//#endregion
//#region src/settings/settings.jsx
var import_jsx_runtime = require_jsx_runtime();
var hasExtensionStorage = () => typeof chrome !== "undefined" && chrome?.storage?.local;
var getStorage = (keys) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve({});
		return;
	}
	chrome.storage.local.get(keys, resolve);
});
var setStorage = (values) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve();
		return;
	}
	chrome.storage.local.set(values, resolve);
});
var removeStorage = (keys) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve();
		return;
	}
	chrome.storage.local.remove(keys, resolve);
});
var providerStorageKeys = {
	deepseek: "apiKey",
	gemini: "geminiApiKey",
	openai: "openaiApiKey"
};
var settingsZh = {
	settings: "设置",
	apiConfig: "API 配置",
	provider: "服务商：",
	deepseek: "DeepSeek",
	gemini: "Gemini",
	openai: "OpenAI",
	deepseekGuide: "DeepSeek API Key 获取指南",
	deepseekStep1: "1. 打开 DeepSeek 开放平台并登录/注册",
	deepseekStep2: "2. 进入 API Keys 页面创建新密钥",
	deepseekStep3: "3. 将密钥粘贴到下方",
	geminiGuide: "Gemini API Key 获取指南",
	geminiStep1: "1. 打开 Google AI Studio 的 API key 页面",
	geminiStep2: "2. 将密钥粘贴到下方",
	openaiGuide: "OpenAI API Key 获取指南",
	openaiStep1: "1. 打开 OpenAI Platform 的 API keys 页面",
	openaiStep2: "2. 创建新密钥并粘贴到下方",
	dataNotice: "数据说明",
	dataNoticeContent: "选中的文本将发送给您选择的 AI 服务商以生成解释。详见我们的隐私政策。",
	privacyPolicy: "隐私政策",
	openDeepseekPlatform: "打开 DeepSeek 平台",
	openDeepseekDocs: "查看 DeepSeek API 文档",
	openGeminiKeys: "打开 Gemini API Key 页面",
	openOpenAIKeys: "打开 OpenAI API Key 页面",
	openPrivacyPolicy: "查看隐私政策",
	apiKeyLabel: "API Key：",
	apiKeyPlaceholder: "sk-...",
	geminiKeyLabel: "Gemini API Key：",
	geminiKeyPlaceholder: "AIza...",
	openaiKeyLabel: "OpenAI API Key：",
	openaiKeyPlaceholder: "sk-...",
	saveKey: "保存密钥",
	clearKey: "清除密钥",
	clearKeyConfirm: "确定要清除已保存的 {provider} API Key 吗？",
	testConnection: "测试连接",
	githubRepository: "GitHub 项目",
	usageStats: "使用统计",
	todayUsage: "今日使用：",
	totalUsage: "累计使用：",
	creditRemaining: "估算剩余额度：",
	usageStatsNote: "按本地请求记录估算 token；真实账单请以服务商控制台为准。",
	hotkeySettings: "快捷键与操作方式",
	explainSelected: "解释选中内容：",
	close: "关闭",
	status_enter_key: "请输入API密钥。详情请查看设置页面。",
	status_invalid_key: "密钥格式无效",
	status_testing: "正在测试连接...",
	status_success: "连接成功！",
	status_key_cleared: "已清除 {provider} API Key。",
	status_invalid_retry: "密钥无效，请重试",
	status_conn_failed: "连接失败",
	mouseClick: "点击弹窗",
	mouseClickStep: "选词并点击后，AI搜索会自动开始。 "
};
var settingsEn = {
	settings: "Settings",
	apiConfig: "API Configurations",
	provider: "Provider:",
	deepseek: "DeepSeek",
	gemini: "Gemini",
	openai: "OpenAI",
	deepseekGuide: "DeepSeek API Key Required",
	deepseekStep1: "1. Open the DeepSeek platform and sign in or register",
	deepseekStep2: "2. Go to API Keys and create a new secret key",
	deepseekStep3: "3. Paste the key below",
	geminiGuide: "Gemini API Key Required",
	geminiStep1: "1. Open the Google AI Studio API key page",
	geminiStep2: "2. Paste the key below",
	openaiGuide: "OpenAI API Key Required",
	openaiStep1: "1. Open the OpenAI Platform API keys page",
	openaiStep2: "2. Create a new secret key and paste it below",
	dataNotice: "Data Notice",
	dataNoticeContent: "Selected text will be sent to your chosen AI provider to generate explanations. See our Privacy Policy.",
	privacyPolicy: "Privacy Policy",
	openDeepseekPlatform: "Open DeepSeek Platform",
	openDeepseekDocs: "View DeepSeek API Docs",
	openGeminiKeys: "Open Gemini API Key Page",
	openOpenAIKeys: "Open OpenAI API Key Page",
	openPrivacyPolicy: "View Privacy Policy",
	apiKeyLabel: "API Key:",
	apiKeyPlaceholder: "sk-...",
	geminiKeyLabel: "Gemini API Key:",
	geminiKeyPlaceholder: "AIza...",
	openaiKeyLabel: "OpenAI API Key:",
	openaiKeyPlaceholder: "sk-...",
	saveKey: "Save Key",
	clearKey: "Clear Key",
	clearKeyConfirm: "Clear the saved {provider} API Key?",
	testConnection: "Test Connection",
	githubRepository: "GitHub Repository",
	usageStats: "Usage Statistics",
	todayUsage: "Today:",
	totalUsage: "Total:",
	creditRemaining: "Estimated remaining:",
	usageStatsNote: "Estimated from local request records. Provider dashboards remain the source of truth.",
	hotkeySettings: "Hotkeys and Manuals",
	explainSelected: "Explain Selected:",
	close: "Close",
	status_enter_key: "Please enter API key to begin searching. Visit settings page for more detail.",
	status_invalid_key: "Invalid API key format",
	status_testing: "Testing connection...",
	status_success: "Success!",
	status_key_cleared: "{provider} API Key cleared.",
	status_invalid_retry: "Invalid API key. Try again.",
	status_conn_failed: "Connection failed",
	mouseClick: "Click",
	mouseClickStep: "When clicking on the popup after text selection, search will automatically begin."
};
var onboardingZh = {
	eyebrow: "Explain This 新手设置",
	step: "第 {current} 步，共 5 步",
	back: "返回",
	continue: "继续",
	speedTitle: "你喜欢怎样的解释？",
	speedBody: "先选择默认的解释详略。之后仍可在 popup 中随时切换。",
	fast: "简明",
	fastHint: "快速给出核心含义，最多三句话",
	detail: "详细",
	detailHint: "包含一句总结、分点说明和例子",
	noticeTitle: "使用前，请了解 API Key",
	principleTitle: "它是怎么工作的？",
	principleBody: "扩展会把文本交给 AI 服务商处理；API Key 用来识别并授权你的账户。",
	principleAnalogy: "打个比方：就像刷自己的门卡请前台办事——扩展负责传话，服务商真正处理请求，Key 决定服务记到谁的账户。",
	noticePrivacyTitle: "会发送什么？",
	noticePrivacyBody: "你要求解释的文本会发送给所选服务商。请勿提交密码、密钥或其他敏感信息。",
	noticeRiskTitle: "你需要承担什么？",
	noticeRiskBody: "你需要负责保管 Key、服务商账户的使用和相关费用；如果 Key 泄露，请立即撤销。",
	localKeyNote: "Key 只保存在此浏览器的本地扩展存储中。",
	privacyPolicy: "查看隐私政策",
	agree: "我已了解并同意继续",
	providerTitle: "选择 AI 服务商",
	providerBody: "选择你已经拥有账户或准备申请 API Key 的服务商。",
	recommended: "推荐",
	freeAvailable: "可用免费",
	providerOpenAI: "通用且稳定，适合大多数内容",
	providerGemini: "Google 的生成式 AI 服务",
	providerDeepSeek: "中文体验好，价格较低",
	keyTitle: "连接 {provider}",
	keyBody: "粘贴你的 API Key。你可以先测试，确认无误后保存并完成设置。",
	keyLabel: "{provider} API Key",
	keyPlaceholder: "在这里粘贴 API Key",
	getKey: "获取 {provider} API Key",
	test: "测试连接",
	testing: "正在测试…",
	save: "保存并完成设置",
	saving: "正在保存…",
	enterKey: "请先输入 API Key",
	testSuccess: "连接成功，可以完成设置。",
	connectionFailed: "连接失败",
	complete: "新手设置已完成。"
};
var onboardingEn = {
	eyebrow: "Explain This setup",
	step: "Step {current} of 5",
	back: "Back",
	continue: "Continue",
	speedTitle: "How detailed should explanations be?",
	speedBody: "Choose your default style. You can switch it anytime from the popup.",
	fast: "Concise",
	fastHint: "The core meaning in no more than three sentences",
	detail: "Detailed",
	detailHint: "A summary followed by key points and an example",
	noticeTitle: "Before you begin: API Keys",
	principleTitle: "How does it work?",
	principleBody: "The extension sends text to an AI provider. Your API Key identifies and authorizes your account.",
	principleAnalogy: "Think of a hotel concierge: the extension passes on your request, the provider does the work, and the key says which account receives the service.",
	noticePrivacyTitle: "What is sent?",
	noticePrivacyBody: "Your text goes to the selected provider. Never submit passwords, keys, or sensitive data.",
	noticeRiskTitle: "What are you responsible for?",
	noticeRiskBody: "You are responsible for your key, provider usage, and charges. Revoke a leaked key immediately.",
	localKeyNote: "Your key is stored only in this browser’s local extension storage.",
	privacyPolicy: "Read the Privacy Policy",
	agree: "I understand and agree to continue",
	providerTitle: "Choose an AI provider",
	providerBody: "Pick a provider where you already have an account or plan to create an API Key.",
	recommended: "Recommended",
	freeAvailable: "Free tier",
	providerOpenAI: "Reliable general-purpose explanations",
	providerGemini: "Google’s generative AI service",
	providerDeepSeek: "Strong Chinese support at a lower cost",
	keyTitle: "Connect {provider}",
	keyBody: "Paste your API Key. You can test it first, then save it to finish setup.",
	keyLabel: "{provider} API Key",
	keyPlaceholder: "Paste your API Key here",
	getKey: "Get a {provider} API Key",
	test: "Test connection",
	testing: "Testing…",
	save: "Save and finish setup",
	saving: "Saving…",
	enterKey: "Enter an API Key first",
	testSuccess: "Connection successful. You can finish setup.",
	connectionFailed: "Connection failed",
	complete: "Welcome setup is complete."
};
var onboardingProviders = [
	{
		id: "openai",
		name: "OpenAI",
		descriptionKey: "providerOpenAI",
		keyUrl: "https://platform.openai.com/api-keys",
		storageKey: "openaiApiKey"
	},
	{
		id: "gemini",
		name: "Gemini",
		descriptionKey: "providerGemini",
		keyUrl: "https://aistudio.google.com/app/apikey",
		recommended: true,
		freeAvailable: true,
		storageKey: "geminiApiKey"
	},
	{
		id: "deepseek",
		name: "DeepSeek",
		descriptionKey: "providerDeepSeek",
		keyUrl: "https://platform.deepseek.com/api_keys",
		storageKey: "apiKey"
	}
];
var formatOnboardingText = (text, values) => Object.entries(values).reduce((result, [key, value]) => result.replace(`{${key}}`, value), text);
async function testProviderConnection(provider, apiKey) {
	let response;
	if (provider === "gemini") response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"x-goog-api-key": apiKey
		},
		body: JSON.stringify({
			contents: [{
				role: "user",
				parts: [{ text: "Reply with OK." }]
			}],
			generationConfig: {
				maxOutputTokens: 32,
				temperature: 0
			}
		})
	});
	else response = await fetch(provider === "openai" ? "https://api.openai.com/v1/models" : "https://api.deepseek.com/v1/models", { headers: { Authorization: `Bearer ${apiKey}` } });
	if (response.ok) return;
	const rawBody = await response.text();
	let details = rawBody || response.statusText;
	try {
		details = JSON.parse(rawBody)?.error?.message || details;
	} catch {}
	throw new Error(`HTTP ${response.status}${details ? `: ${details}` : ""}`);
}
function InfoBox({ boxId, title, children, style }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "info-box",
		id: boxId,
		style,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: title }), children]
	});
}
function StatItem({ id, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stat-item",
		id,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "stat-label",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "stat-value",
			children
		})]
	});
}
function Section({ id, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "section",
		id,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-title",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: title })]
		}), children]
	});
}
function isMacPlatform() {
	return /Mac|iPhone|iPad|iPod/i.test(navigator.platform);
}
function LinkButton({ href, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		className: "guide-link",
		href,
		target: "_blank",
		rel: "noreferrer",
		children
	});
}
function SettingsOnboarding({ lang, initialSpeed, initialProvider, savedKeys, onComplete }) {
	const [step, setStep] = (0, import_react.useState)(1);
	const [speed, setSpeed] = (0, import_react.useState)(initialSpeed || "fast");
	const [provider, setProvider] = (0, import_react.useState)(initialProvider || "openai");
	const [apiKey, setApiKey] = (0, import_react.useState)(savedKeys[(onboardingProviders.find((option) => option.id === initialProvider) || onboardingProviders[0]).storageKey] || "");
	const [status, setStatus] = (0, import_react.useState)({
		message: "",
		type: ""
	});
	const [testing, setTesting] = (0, import_react.useState)(false);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const t = lang === "zh" ? onboardingZh : onboardingEn;
	const selectedProvider = onboardingProviders.find((option) => option.id === provider) || onboardingProviders[0];
	const privacyUrl = "https://github.com/HeyiCAo/ExplainThis/blob/main/privacy-policy.md";
	const overallStep = step + 1;
	const goToStep = (nextStep) => {
		setStatus({
			message: "",
			type: ""
		});
		setStep(nextStep);
	};
	const handleSpeedChange = (nextSpeed) => {
		setSpeed(nextSpeed);
		setStorage({ explainSpeed: nextSpeed });
	};
	const handleProviderChange = (option) => {
		setProvider(option.id);
		setApiKey(savedKeys[option.storageKey] || "");
		setStatus({
			message: "",
			type: ""
		});
	};
	const handleTest = async () => {
		const normalizedKey = apiKey.trim();
		if (!normalizedKey) {
			setStatus({
				message: t.enterKey,
				type: "error"
			});
			return;
		}
		setTesting(true);
		setStatus({
			message: "",
			type: ""
		});
		try {
			await testProviderConnection(provider, normalizedKey);
			setStatus({
				message: t.testSuccess,
				type: "success"
			});
		} catch (error) {
			setStatus({
				message: `${t.connectionFailed}: ${error.message}`,
				type: "error"
			});
		} finally {
			setTesting(false);
		}
	};
	const handleSave = async () => {
		const normalizedKey = apiKey.trim();
		if (!normalizedKey) {
			setStatus({
				message: t.enterKey,
				type: "error"
			});
			return;
		}
		setSaving(true);
		await setStorage({
			[selectedProvider.storageKey]: normalizedKey,
			provider,
			lang,
			explainSpeed: speed,
			onboardingComplete: true,
			onboardingStarted: false
		});
		setSaving(false);
		onComplete({
			provider,
			speed,
			apiKey: normalizedKey,
			storageKey: selectedProvider.storageKey,
			message: t.complete
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "settings-onboarding-shell",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "settings-onboarding-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "settings-onboarding-topline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.eyebrow }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatOnboardingText(t.step, { current: overallStep }) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "settings-onboarding-progress",
					"aria-hidden": "true",
					children: [
						1,
						2,
						3,
						4,
						5
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: item <= overallStep ? "active" : "" }, item))
				}),
				step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "settings-onboarding-page",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "settings-onboarding-icon",
							children: "≡"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: t.speedTitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "settings-onboarding-intro",
							children: t.speedBody
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-choice-grid speed-choices",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: `settings-choice ${speed === "fast" ? "selected" : ""}`,
								onClick: () => handleSpeedChange("fast"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "settings-choice-icon",
										children: "⚡"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.fast }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t.fastHint })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "settings-choice-radio" })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: `settings-choice ${speed === "detail" ? "selected" : ""}`,
								onClick: () => handleSpeedChange("detail"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "settings-choice-icon",
										children: "☷"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.detail }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t.detailHint })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "settings-choice-radio" })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "settings-onboarding-actions single",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "settings-onboarding-primary",
								onClick: () => goToStep(2),
								children: t.continue
							})
						})
					]
				}),
				step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "settings-onboarding-page compact",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "settings-onboarding-icon notice",
							children: "!"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: t.noticeTitle }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-principle-box",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.principleTitle }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.principleBody }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "analogy",
									children: t.principleAnalogy
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-notice-list",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "↗" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.noticePrivacyTitle }), t.noticePrivacyBody] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "◇" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.noticeRiskTitle }), t.noticeRiskBody] })] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "settings-local-key-note",
							children: t.localKeyNote
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							className: "settings-onboarding-link",
							href: privacyUrl,
							target: "_blank",
							rel: "noreferrer",
							children: [t.privacyPolicy, " ↗"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-onboarding-actions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "settings-onboarding-secondary",
								onClick: () => goToStep(1),
								children: t.back
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "settings-onboarding-primary",
								onClick: () => goToStep(3),
								children: t.agree
							})]
						})
					]
				}),
				step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "settings-onboarding-page",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "settings-onboarding-icon",
							children: "AI"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: t.providerTitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "settings-onboarding-intro",
							children: t.providerBody
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "settings-choice-grid provider-choices",
							children: onboardingProviders.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: `settings-choice ${provider === option.id ? "selected" : ""}`,
								onClick: () => handleProviderChange(option),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `settings-choice-icon ${option.id}`,
										children: option.name.charAt(0)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
										option.name,
										option.recommended && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: t.recommended }),
										option.freeAvailable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
											className: "free",
											children: t.freeAvailable
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t[option.descriptionKey] })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "settings-choice-radio" })
								]
							}, option.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-onboarding-actions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "settings-onboarding-secondary",
								onClick: () => goToStep(2),
								children: t.back
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "settings-onboarding-primary",
								onClick: () => goToStep(4),
								children: t.continue
							})]
						})
					]
				}),
				step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "settings-onboarding-page",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `settings-onboarding-icon ${provider}`,
							children: selectedProvider.name.charAt(0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: formatOnboardingText(t.keyTitle, { provider: selectedProvider.name }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "settings-onboarding-intro",
							children: t.keyBody
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "settings-onboarding-key",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatOnboardingText(t.keyLabel, { provider: selectedProvider.name }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								value: apiKey,
								onChange: (event) => {
									setApiKey(event.target.value);
									setStatus({
										message: "",
										type: ""
									});
								},
								placeholder: t.keyPlaceholder,
								autoComplete: "off",
								spellCheck: "false"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-key-meta",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "settings-onboarding-link",
								href: selectedProvider.keyUrl,
								target: "_blank",
								rel: "noreferrer",
								children: [formatOnboardingText(t.getKey, { provider: selectedProvider.name }), " ↗"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.localKeyNote })]
						}),
						status.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `settings-onboarding-status ${status.type}`,
							role: "status",
							children: status.message
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-onboarding-actions key-actions",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "settings-onboarding-secondary",
									onClick: () => goToStep(3),
									children: t.back
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "settings-onboarding-secondary",
									onClick: handleTest,
									disabled: testing || saving,
									children: testing ? t.testing : t.test
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "settings-onboarding-primary",
									onClick: handleSave,
									disabled: testing || saving,
									children: saving ? t.saving : t.save
								})
							]
						})
					]
				})
			]
		})
	});
}
function SettingsPage() {
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [provider, setProvider] = (0, import_react.useState)("openai");
	const [lang, setLang] = (0, import_react.useState)("zh");
	const [status, setStatus] = (0, import_react.useState)({
		message: "",
		type: ""
	});
	const [usageStats, setUsageStats] = (0, import_react.useState)(normalizeUsageStats());
	const [apiKey, setApiKey] = (0, import_react.useState)("");
	const [speed, setSpeed] = (0, import_react.useState)("fast");
	const [savedKeys, setSavedKeys] = (0, import_react.useState)({
		apiKey: "",
		geminiApiKey: "",
		openaiApiKey: ""
	});
	const [onboardingRequired, setOnboardingRequired] = (0, import_react.useState)(null);
	const t = lang === "zh" ? settingsZh : settingsEn;
	const shortcutModifier = isMacPlatform() ? "Cmd" : "Ctrl";
	const privacyUrl = "https://github.com/HeyiCAo/ExplainThis/blob/main/privacy-policy.md";
	const repositoryUrl = "https://github.com/HeyiCAo/ExplainThis";
	(0, import_react.useEffect)(() => {
		getStorage([
			"apiKey",
			"geminiApiKey",
			"openaiApiKey",
			"provider",
			"lang",
			"explainSpeed",
			"onboardingComplete"
		]).then((result) => {
			const savedProvider = result.provider || "openai";
			const nextSavedKeys = {
				apiKey: result.apiKey || "",
				geminiApiKey: result.geminiApiKey || "",
				openaiApiKey: result.openaiApiKey || ""
			};
			const hasSavedKey = Object.values(nextSavedKeys).some((key) => String(key).trim());
			setProvider(savedProvider);
			setSavedKeys(nextSavedKeys);
			if (savedProvider === "gemini") setApiKey(result.geminiApiKey || "");
			else if (savedProvider === "openai") setApiKey(result.openaiApiKey || "");
			else setApiKey(result.apiKey || "");
			if (result.lang) setLang(result.lang);
			if (result.explainSpeed) setSpeed(result.explainSpeed);
			setOnboardingRequired(!(result.onboardingComplete === true || hasSavedKey));
			if (hasSavedKey && result.onboardingComplete !== true) setStorage({
				onboardingComplete: true,
				onboardingStarted: false
			});
		});
	}, []);
	(0, import_react.useEffect)(() => {
		getUsageStats().then(setUsageStats);
		if (typeof chrome === "undefined" || !chrome?.storage?.onChanged) return void 0;
		const handleStorageChange = (changes, areaName) => {
			if (areaName !== "local" || !changes.usageStats) return;
			setUsageStats(normalizeUsageStats(changes.usageStats.newValue));
		};
		chrome.storage.onChanged.addListener(handleStorageChange);
		return () => chrome.storage.onChanged.removeListener(handleStorageChange);
	}, []);
	function handleProviderChange(nextProvider) {
		setMenuOpen(false);
		setProvider(nextProvider);
		setStorage({ provider: nextProvider });
		getStorage([
			"apiKey",
			"geminiApiKey",
			"openaiApiKey"
		]).then((result) => {
			if (nextProvider === "gemini") setApiKey(result.geminiApiKey || "");
			else if (nextProvider === "openai") setApiKey(result.openaiApiKey || "");
			else setApiKey(result.apiKey || "");
		});
	}
	function handleClose() {
		if (typeof chrome !== "undefined" && chrome?.tabs?.getCurrent && chrome?.tabs?.remove) {
			chrome.tabs.getCurrent((tab) => {
				if (tab?.id) chrome.tabs.remove(tab.id);
				else window.close();
			});
			return;
		}
		window.close();
	}
	function handleSaveKey() {
		const normalizedKey = apiKey.trim();
		if (!normalizedKey) {
			setStatus({
				message: t.status_enter_key,
				type: "error"
			});
			return;
		}
		let keyPayload;
		if (provider === "gemini") keyPayload = {
			provider,
			geminiApiKey: normalizedKey
		};
		else if (provider === "openai") keyPayload = {
			provider,
			openaiApiKey: normalizedKey
		};
		else keyPayload = {
			provider,
			apiKey: normalizedKey
		};
		setStorage(keyPayload);
		setApiKey(normalizedKey);
		setSavedKeys((current) => ({
			...current,
			[providerStorageKeys[provider]]: normalizedKey
		}));
		setStatus({
			message: t.status_success,
			type: "success"
		});
	}
	async function handleClearKey() {
		const providerName = onboardingProviders.find((option) => option.id === provider)?.name || provider;
		const confirmMessage = formatOnboardingText(t.clearKeyConfirm, { provider: providerName });
		if (!window.confirm(confirmMessage)) return;
		const storageKey = providerStorageKeys[provider];
		await removeStorage(storageKey);
		setApiKey("");
		setSavedKeys((current) => ({
			...current,
			[storageKey]: ""
		}));
		setStatus({
			message: formatOnboardingText(t.status_key_cleared, { provider: providerName }),
			type: "success"
		});
	}
	async function handleTestConnection() {
		const normalizedKey = apiKey.trim();
		if (!normalizedKey) {
			setStatus({
				message: t.status_enter_key,
				type: "error"
			});
			return;
		}
		setStatus({
			message: t.status_testing,
			type: "info"
		});
		let response;
		if (provider === "deepseek") try {
			response = await fetch("https://api.deepseek.com/v1/models", { headers: { "Authorization": `Bearer ${normalizedKey}` } });
		} catch (error) {
			setStatus({
				message: `${t.status_conn_failed}: ${error.message}`,
				type: "error"
			});
			return;
		}
		else if (provider === "gemini") try {
			response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					"x-goog-api-key": normalizedKey
				},
				body: JSON.stringify({
					contents: [{
						role: "user",
						parts: [{ text: "Reply with OK." }]
					}],
					generationConfig: {
						maxOutputTokens: 32,
						temperature: 0
					}
				})
			});
		} catch (error) {
			setStatus({
				message: `${t.status_conn_failed}: ${error.message}`,
				type: "error"
			});
			return;
		}
		else if (provider === "openai") try {
			response = await fetch("https://api.openai.com/v1/models", { headers: { "Authorization": `Bearer ${normalizedKey}` } });
		} catch (error) {
			setStatus({
				message: `${t.status_conn_failed}: ${error.message}`,
				type: "error"
			});
			return;
		}
		if (response.ok) {
			setApiKey(normalizedKey);
			setStatus({
				message: t.status_success,
				type: "success"
			});
			return;
		}
		const rawBody = await response.text();
		let details;
		try {
			const payload = JSON.parse(rawBody);
			details = payload?.error?.message || JSON.stringify(payload);
		} catch {
			details = rawBody || response.statusText;
		}
		setStatus({
			message: `${t.status_conn_failed} (HTTP ${response.status})${details ? `: ${details}` : ""}`,
			type: "error"
		});
	}
	if (onboardingRequired === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "settings-initializing",
		"aria-label": "Loading"
	});
	if (onboardingRequired) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsOnboarding, {
		lang,
		initialSpeed: speed,
		initialProvider: provider,
		savedKeys,
		onComplete: ({ provider: nextProvider, speed: nextSpeed, apiKey: nextKey, storageKey, message }) => {
			setProvider(nextProvider);
			setSpeed(nextSpeed);
			setApiKey(nextKey);
			setSavedKeys((current) => ({
				...current,
				[storageKey]: nextKey
			}));
			setStatus({
				message,
				type: "success"
			});
			setOnboardingRequired(false);
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "top-bar",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.settings }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "top-actions",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: "github-link",
					href: repositoryUrl,
					target: "_blank",
					rel: "noreferrer",
					children: [t.githubRepository, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						children: "↗"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "lang-switch",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setLang("zh");
							setStorage({ lang: "zh" });
						},
						className: lang === "zh" ? "active" : "",
						children: "中"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setLang("en");
							setStorage({ lang: "en" });
						},
						className: lang === "en" ? "active" : "",
						children: "EN"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "close-btn",
					onClick: handleClose,
					children: t.close
				})
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "section-grid",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
			id: "apiConfig",
			title: t.apiConfig,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: "providerToggle",
					children: t.provider
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "provider-wrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "provider-toggle",
						type: "button",
						"aria-haspopup": "listbox",
						onClick: () => setMenuOpen(!menuOpen),
						children: [provider === "deepseek" ? "DeepSeek" : provider === "gemini" ? "Gemini" : "OpenAI", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "▾" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `provider-menu${menuOpen ? " open" : ""}`,
						role: "listbox",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "provider-item",
								role: "option",
								onClick: () => handleProviderChange("deepseek"),
								children: "DeepSeek"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "provider-item",
								role: "option",
								onClick: () => handleProviderChange("gemini"),
								children: "Gemini"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "provider-item",
								role: "option",
								onClick: () => handleProviderChange("openai"),
								children: "OpenAI"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoBox, {
					title: t.deepseekGuide,
					style: { display: provider === "deepseek" ? "block" : "none" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						style: { margin: "10px 0 0 0" },
						children: [
							t.deepseekStep1,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							t.deepseekStep2,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							t.deepseekStep3,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "guide-links",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkButton, {
							href: "https://platform.deepseek.com/",
							children: t.openDeepseekPlatform
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkButton, {
							href: "https://api-docs.deepseek.com/",
							children: t.openDeepseekDocs
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoBox, {
					title: t.geminiGuide,
					style: { display: provider === "gemini" ? "block" : "none" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						style: { margin: "10px 0 0 0" },
						children: [
							t.geminiStep1,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							t.geminiStep2,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "guide-links",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkButton, {
							href: "https://aistudio.google.com/app/apikey",
							children: t.openGeminiKeys
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoBox, {
					title: t.openaiGuide,
					style: { display: provider === "openai" ? "block" : "none" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						style: { margin: "10px 0 0 0" },
						children: [
							t.openaiStep1,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							t.openaiStep2,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "guide-links",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkButton, {
							href: "https://platform.openai.com/api-keys",
							children: t.openOpenAIKeys
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InfoBox, {
					title: t.dataNotice,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						style: { margin: "8px 0 0 0" },
						children: t.dataNoticeContent
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "guide-links",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkButton, {
							href: privacyUrl,
							children: t.openPrivacyPolicy
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					style: { display: provider === "deepseek" ? "block" : "none" },
					children: t.apiKeyLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					placeholder: "sk-...",
					value: apiKey,
					style: { display: provider === "deepseek" ? "block" : "none" },
					onChange: (e) => setApiKey(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					style: { display: provider === "gemini" ? "block" : "none" },
					children: t.geminiKeyLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					placeholder: "AIza...",
					value: apiKey,
					style: { display: provider === "gemini" ? "block" : "none" },
					onChange: (e) => setApiKey(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					style: { display: provider === "openai" ? "block" : "none" },
					children: t.openaiKeyLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					placeholder: "sk-...",
					value: apiKey,
					style: { display: provider === "openai" ? "block" : "none" },
					onChange: (e) => setApiKey(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "button-group",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "primary-btn",
							onClick: handleSaveKey,
							children: t.saveKey
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "secondary-btn",
							onClick: handleTestConnection,
							children: t.testConnection
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "danger-btn",
							onClick: handleClearKey,
							children: t.clearKey
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `status ${status.type}`,
					children: status.message
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "right-column",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "usageStats",
				title: t.usageStats,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StatItem, {
						id: "todayUsage",
						title: t.todayUsage,
						children: [
							usageStats.todayRequests,
							" / ",
							formatTokenCount(usageStats.todayTokens)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StatItem, {
						id: "totalUsage",
						title: t.totalUsage,
						children: [
							usageStats.totalRequests,
							" / ",
							formatTokenCount(usageStats.totalTokens)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatItem, {
						id: "creditRemaining",
						title: t.creditRemaining,
						children: formatTokenCount(remainingTokens(usageStats))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "stats-note",
						children: t.usageStatsNote
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "hotkeySettings",
				title: t.hotkeySettings,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StatItem, {
					id: "explainSelected",
					title: t.explainSelected,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: shortcutModifier }),
						"+",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "E" })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatItem, {
					id: "explainSelected",
					title: t.mouseClick,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: t.mouseClickStep })
				})]
			})]
		})]
	})] });
}
//#endregion
//#region src/settings/main.jsx
import_client.createRoot(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPage, {}) }));
//#endregion
