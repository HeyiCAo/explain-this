import { a as recordUsage, c as __toESM, o as require_client, s as require_react, t as require_jsx_runtime } from "./jsx-runtime-HCt1rUt2.js";
//#region src/styles.css
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_client = /* @__PURE__ */ __toESM(require_client(), 1);
//#endregion
//#region src/shared/apiService.js
var BUILT_IN_API_BASE_URL = "https://explain-this-api.explainthis-hc907.workers.dev/v1".replace(/\/+$/, "");
var STORAGE_KEYS = [
	"aiMode",
	"apiKey",
	"geminiApiKey",
	"openaiApiKey",
	"provider",
	"installId"
];
var AIServiceError = class extends Error {
	constructor(code, message = code, details = {}) {
		super(message);
		this.name = "AIServiceError";
		this.code = code;
		this.details = details;
	}
};
var AIService = class {
	constructor() {
		this.apiKey = "";
		this.mode = "builtIn";
		this.provider = "openai";
		this.installId = "";
		this.deepseekBaseURL = "https://api.deepseek.com/v1";
		this.deepseekModel = "deepseek-chat";
		this.geminiBaseURL = "https://generativelanguage.googleapis.com/v1beta";
		this.geminiModel = "gemini-3.5-flash";
		this.openaiBaseURL = "https://api.openai.com/v1";
		this.openaiModel = "gpt-5.4-mini";
	}
	getStorage(keys) {
		return new Promise((resolve) => {
			if (typeof chrome === "undefined" || !chrome?.storage?.local) {
				resolve({});
				return;
			}
			chrome.storage.local.get(keys, resolve);
		});
	}
	setStorage(values) {
		return new Promise((resolve) => {
			if (typeof chrome === "undefined" || !chrome?.storage?.local) {
				resolve();
				return;
			}
			chrome.storage.local.set(values, resolve);
		});
	}
	async loadConfiguration() {
		const result = await this.getStorage(STORAGE_KEYS);
		const hasSavedKey = [
			result.apiKey,
			result.geminiApiKey,
			result.openaiApiKey
		].some((key) => String(key || "").trim());
		this.mode = result.aiMode || (hasSavedKey ? "byok" : "builtIn");
		this.provider = result.provider || "openai";
		this.installId = result.installId || "";
		if (this.provider === "gemini") this.apiKey = result.geminiApiKey || "";
		else if (this.provider === "deepseek") this.apiKey = result.apiKey || "";
		else this.apiKey = result.openaiApiKey || "";
		this.apiKey = String(this.apiKey).trim();
		if (!this.installId) {
			this.installId = globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
			await this.setStorage({ installId: this.installId });
		}
		return {
			mode: this.mode,
			provider: this.provider,
			apiKey: this.apiKey,
			installId: this.installId
		};
	}
	async explainText(text, options = {}) {
		await this.loadConfiguration();
		if (this.mode === "builtIn") return this.explainWithBuiltInAI(text, options, false);
		this.assertByokKey();
		const request = this.buildByokRequest(text, options);
		if (this.provider === "gemini") return this.explainWithGemini(request.prompt, request.isFast, request.systemContent);
		if (this.provider === "openai") return this.explainWithOpenAI(request.prompt, request.isFast, request.systemContent);
		return this.explainWithDeepSeek(request.prompt, request.isFast, request.systemContent);
	}
	async explainTextStream(text, options = {}, onChunk = () => {}) {
		await this.loadConfiguration();
		if (this.mode === "builtIn") return this.explainWithBuiltInAI(text, options, true, onChunk);
		this.assertByokKey();
		const request = this.buildByokRequest(text, options);
		if (this.provider === "gemini") return this.explainGeminiStream(request.prompt, request.isFast, request.systemContent, onChunk);
		if (this.provider === "openai") return this.explainOpenAIStream(request.prompt, request.isFast, request.systemContent, onChunk);
		return this.explainDeepSeekStream(request.prompt, request.isFast, request.systemContent, onChunk);
	}
	assertByokKey() {
		if (!this.apiKey) throw new AIServiceError("BYOK_KEY_REQUIRED", "A personal API key is required in Bring Your Own Key mode.");
	}
	buildByokRequest(text, options) {
		const language = options.language || "zh";
		const isFast = (options.speed || "fast") === "fast";
		return {
			prompt: this.buildPrompt(text, options),
			systemContent: this.buildSystemContent(language, isFast),
			isFast
		};
	}
	async explainWithBuiltInAI(text, options, stream, onChunk = () => {}) {
		let response;
		try {
			response = await fetch(`${BUILT_IN_API_BASE_URL}/explain`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					"X-ExplainThis-Client": this.installId
				},
				body: JSON.stringify({
					text,
					language: options.language || "zh",
					style: options.speed || "fast",
					stream
				})
			});
		} catch {
			throw new AIServiceError("SERVICE_UNAVAILABLE");
		}
		await this.storeFreeUsageFromResponse(response);
		if (!response.ok) throw await this.createProxyError(response);
		if (!stream) {
			const data = await response.json();
			return this.formatExplanation(data.explanation || "");
		}
		const fullText = await this.readSseStream(response, (data) => {
			const delta = data.delta || "";
			if (delta) onChunk(delta);
			return delta;
		});
		return this.formatExplanation(fullText);
	}
	async createProxyError(response) {
		let payload = {};
		try {
			payload = await response.json();
		} catch {}
		const code = payload?.error?.code || (response.status === 413 ? "TEXT_TOO_LONG" : response.status === 429 ? "RATE_LIMITED" : "SERVICE_UNAVAILABLE");
		return new AIServiceError(code, code, {
			retryAfter: payload?.error?.retryAfter,
			resetAt: payload?.error?.resetAt,
			maxCharacters: payload?.error?.maxCharacters
		});
	}
	async storeFreeUsageFromResponse(response) {
		const limit = Number(response.headers.get("X-RateLimit-Limit"));
		const remaining = Number(response.headers.get("X-RateLimit-Remaining"));
		const resetAt = response.headers.get("X-RateLimit-Reset");
		if (!Number.isFinite(limit) || !Number.isFinite(remaining)) return;
		await this.setStorage({ freeUsage: {
			date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
			limit,
			remaining: Math.max(0, remaining),
			resetAt: resetAt || null,
			updatedAt: Date.now()
		} });
	}
	async explainDeepSeekStream(prompt, isFast, systemContent, onChunk) {
		const response = await fetch(`${this.deepseekBaseURL}/chat/completions`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${this.apiKey}`
			},
			body: JSON.stringify({
				model: this.deepseekModel,
				messages: [{
					role: "system",
					content: systemContent
				}, {
					role: "user",
					content: prompt
				}],
				max_tokens: isFast ? 800 : 2e3,
				temperature: isFast ? .1 : .4,
				stream: true
			})
		});
		if (!response.ok) throw new AIServiceError("PROVIDER_ERROR");
		const fullText = await this.readSseStream(response, (data) => {
			const delta = data.choices?.[0]?.delta?.content || "";
			if (delta) onChunk(delta);
			return delta;
		});
		return this.formatExplanation(fullText);
	}
	async explainOpenAIStream(prompt, isFast, systemContent, onChunk) {
		const response = await fetch(`${this.openaiBaseURL}/responses`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${this.apiKey}`
			},
			body: JSON.stringify({
				model: this.openaiModel,
				instructions: systemContent,
				input: prompt,
				max_output_tokens: isFast ? 800 : 2e3,
				stream: true
			})
		});
		if (!response.ok) throw new AIServiceError("PROVIDER_ERROR");
		const fullText = await this.readSseStream(response, (data) => {
			const delta = data.type === "response.output_text.delta" ? data.delta || "" : "";
			if (delta) onChunk(delta);
			return delta;
		});
		return this.formatExplanation(fullText);
	}
	async explainGeminiStream(prompt, isFast, systemContent, onChunk) {
		const response = await fetch(`${this.geminiBaseURL}/models/${this.geminiModel}:streamGenerateContent?alt=sse`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"x-goog-api-key": this.apiKey
			},
			body: JSON.stringify({
				system_instruction: { parts: [{ text: systemContent }] },
				contents: [{
					role: "user",
					parts: [{ text: prompt }]
				}],
				generationConfig: {
					maxOutputTokens: isFast ? 800 : 2e3,
					temperature: isFast ? .1 : .4
				}
			})
		});
		if (!response.ok) throw new AIServiceError("PROVIDER_ERROR");
		const fullText = await this.readSseStream(response, (data) => {
			const delta = (data.candidates?.[0]?.content?.parts || []).map((part) => part.text || "").join("");
			if (delta) onChunk(delta);
			return delta;
		});
		return this.formatExplanation(fullText);
	}
	async readSseStream(response, extractDelta) {
		const reader = response.body?.getReader();
		if (!reader) throw new AIServiceError("STREAM_UNAVAILABLE");
		const decoder = new TextDecoder();
		let buffer = "";
		let fullText = "";
		while (true) {
			const { value, done } = await reader.read();
			if (done) break;
			buffer += decoder.decode(value, { stream: true });
			const lines = buffer.split(/\r?\n/);
			buffer = lines.pop() || "";
			for (const line of lines) {
				const trimmed = line.trim();
				if (!trimmed.startsWith("data:")) continue;
				const payload = trimmed.slice(5).trim();
				if (!payload || payload === "[DONE]") continue;
				try {
					const delta = extractDelta(JSON.parse(payload));
					fullText += delta || "";
				} catch {}
			}
		}
		return fullText;
	}
	buildSystemContent(language, isFast) {
		return `${isFast ? language === "en" ? "You are a concise explainer. Give only one short paragraph of at most three sentences." : "你是一个简明的解释助手。请仅用一段不超过三句话的内容说明核心含义。" : language === "en" ? "You are a professional explainer. Use simple language and include a helpful example." : "你是一个专业的解释助手。请用简单易懂的语言详细解释，并给出有帮助的例子。"}\n${isFast ? "" : language === "en" ? "Start with a one-sentence summary, then key points, then one relevant example." : "先用一句话总结，再分点说明，最后给出一个相关例子。"}\n${language === "en" ? "Use English for the entire response." : "请全程使用中文回答。"}`;
	}
	async explainWithDeepSeek(prompt, isFast, systemContent) {
		const response = await fetch(`${this.deepseekBaseURL}/chat/completions`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${this.apiKey}`
			},
			body: JSON.stringify({
				model: this.deepseekModel,
				messages: [{
					role: "system",
					content: systemContent
				}, {
					role: "user",
					content: prompt
				}],
				max_tokens: isFast ? 800 : 2e3,
				temperature: isFast ? .1 : .4
			})
		});
		if (!response.ok) throw new AIServiceError("PROVIDER_ERROR");
		const data = await response.json();
		return this.formatExplanation(data.choices?.[0]?.message?.content || "");
	}
	async explainWithGemini(prompt, isFast, systemContent) {
		const response = await fetch(`${this.geminiBaseURL}/models/${this.geminiModel}:generateContent`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"x-goog-api-key": this.apiKey
			},
			body: JSON.stringify({
				system_instruction: { parts: [{ text: systemContent }] },
				contents: [{
					role: "user",
					parts: [{ text: prompt }]
				}],
				generationConfig: {
					maxOutputTokens: isFast ? 800 : 2e3,
					temperature: isFast ? .1 : .4
				}
			})
		});
		if (!response.ok) throw new AIServiceError("PROVIDER_ERROR");
		const text = ((await response.json()).candidates?.[0]?.content?.parts || []).map((part) => part.text || "").join("");
		return this.formatExplanation(text);
	}
	async explainWithOpenAI(prompt, isFast, systemContent) {
		const response = await fetch(`${this.openaiBaseURL}/responses`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${this.apiKey}`
			},
			body: JSON.stringify({
				model: this.openaiModel,
				instructions: systemContent,
				input: prompt,
				max_output_tokens: isFast ? 800 : 2e3
			})
		});
		if (!response.ok) throw new AIServiceError("PROVIDER_ERROR");
		const data = await response.json();
		return this.formatExplanation(this.extractOpenAIText(data));
	}
	extractOpenAIText(data) {
		if (data.output_text) return data.output_text;
		return (data.output || []).flatMap((item) => item.content || []).map((content) => content.text || "").join("");
	}
	buildPrompt(text, options) {
		let prompt = `${(options.language || "zh") === "en" ? "Explain: " : "请解释："}${text}`;
		if (options.context) prompt += `\n上下文：${options.context}`;
		return prompt;
	}
	formatExplanation(explanation) {
		const html = this.escapeHtml(explanation).replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>").replace(/\*(.*?)\*/g, "<em>$1</em>").replace(/`(.*?)`/g, "<code>$1</code>").replace(/\n/g, "<br>");
		return this.sanitizeHtml(this.renderMath(html));
	}
	escapeHtml(text) {
		return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
	}
	sanitizeHtml(html) {
		const allowedTags = new Set([
			"strong",
			"em",
			"code",
			"br",
			"span",
			"div",
			"sub",
			"sup"
		]);
		const allowedClass = new Set([
			"math-inline",
			"math-display",
			"frac",
			"num",
			"den",
			"op"
		]);
		const template = document.createElement("template");
		template.innerHTML = html;
		const walk = (node) => {
			Array.from(node.childNodes).forEach((child) => {
				if (child.nodeType !== Node.ELEMENT_NODE) return;
				const tag = child.tagName.toLowerCase();
				if (!allowedTags.has(tag)) {
					child.replaceWith(document.createTextNode(child.textContent || ""));
					return;
				}
				Array.from(child.attributes).forEach((attr) => {
					if (attr.name === "class") {
						const classes = attr.value.split(/\s+/).filter((className) => allowedClass.has(className));
						classes.length ? child.setAttribute("class", classes.join(" ")) : child.removeAttribute("class");
					} else child.removeAttribute(attr.name);
				});
				walk(child);
			});
		};
		walk(template.content);
		return template.innerHTML;
	}
	renderMath(html) {
		let out = html;
		out = out.replace(/\\\[((?:.|\n)*?)\\\]/g, (match, content) => `<div class="math-display">${this.latexToHtml(content)}</div>`);
		out = out.replace(/\\\((.*?)\\\)/g, (match, content) => `<span class="math-inline">${this.latexToHtml(content)}</span>`);
		return out;
	}
	latexToHtml(latex) {
		if (!latex) return "";
		let value = latex.replace(/\\Delta/g, "Δ").replace(/\\to/g, "→").replace(/\\infty/g, "∞").replace(/\\cdot/g, "·").replace(/\\times/g, "×").replace(/\\leq/g, "≤").replace(/\\geq/g, "≥");
		for (let index = 0; index < 3; index += 1) value = value.replace(/\\frac\{([^{}]+)\}\{([^{}]+)\}/g, (match, top, bottom) => `<span class="frac"><span class="num">${top}</span><span class="den">${bottom}</span></span>`);
		value = value.replace(/_({[^}]+}|[^\s^_])/g, (match) => {
			return `<sub>${match.slice(1).replace(/^\{|\}$/g, "")}</sub>`;
		});
		value = value.replace(/\^({[^}]+}|[^\s^_])/g, (match) => {
			return `<sup>${match.slice(1).replace(/^\{|\}$/g, "")}</sup>`;
		});
		value = value.replace(/\\lim<sub>(.*?)<\/sub>/g, (match, subscript) => `<span class="op">lim</span><sub>${subscript}</sub>`);
		return value.replace(/\\lim/g, "<span class=\"op\">lim</span>");
	}
};
//#endregion
//#region src/popup/popup.jsx
var import_jsx_runtime = require_jsx_runtime();
var hasExtensionStorage = () => typeof chrome !== "undefined" && chrome?.storage?.local;
var getStorage = (keys) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve({});
		return;
	}
	chrome.storage.local.get(keys, resolve);
});
var setStorage = (values) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve();
		return;
	}
	chrome.storage.local.set(values, resolve);
});
var popupZh = {
	app_title: "Explain This",
	input_placeholder: "粘贴或输入你不懂的内容...\n例如：'内卷是什么意思？'\n      'Python中的装饰器怎么理解？'\n      '这个历史典故有什么背景？'",
	ask_ai: "发送",
	speed_label: "速度",
	speed_fast: "快",
	speed_detail: "详",
	results_title: "结果",
	thinking: "思考中...",
	history_title: "最近记录",
	clear_history: "清空",
	empty_input: "请输入要解释的内容",
	retry: "重试",
	built_in: "内置 AI",
	byok: "自带 Key",
	free_left: "今日剩余 {count} 次",
	quota_exceeded: "你已用完今天的 50 次免费解释。请明天再来，或在高级设置中添加自己的 API Key。",
	text_too_long: "免费模式下这段文字太长了。请缩短到 1000 字以内，或使用自己的 API Key。",
	rate_limited: "请求有点频繁，请稍等片刻再试。",
	key_required: "请先在高级设置中添加自己的 API Key，或切换回内置 AI。",
	generic_error: "解释暂时失败，请稍后再试。"
};
var popupEn = {
	app_title: "Explain This",
	input_placeholder: "Paste or type what you don't understand...",
	ask_ai: "Ask",
	speed_label: "Speed",
	speed_fast: "Fast",
	speed_detail: "Detail",
	results_title: "Results",
	thinking: "Thinking...",
	history_title: "Recent",
	clear_history: "Clear",
	empty_input: "Please enter text to explain",
	retry: "Try Again",
	built_in: "Built-in AI",
	byok: "Your API key",
	free_left: "{count} free today",
	quota_exceeded: "You’ve used today’s 50 free explanations. Come back tomorrow or add your own API key.",
	text_too_long: "This selection is too long for the free plan. Try a shorter passage or use your own API key.",
	rate_limited: "That was a little too fast. Please wait a moment and try again.",
	key_required: "Add your API key in Advanced settings, or switch back to Built-in AI.",
	generic_error: "Explanation failed. Please try again in a moment."
};
var firstRunZh = {
	eyebrow: "欢迎使用 Explain This",
	step: "第 1 步，共 4 步",
	continue: "继续前往设置",
	opening: "正在打开设置…",
	languageTitle: "选择你的使用语言",
	languageBody: "这会决定界面和 AI 回答的默认语言，之后仍可随时切换。",
	chinese: "中文",
	chineseHint: "使用中文界面和回答",
	english: "English",
	englishHint: "Use the app and AI in English"
};
var firstRunEn = {
	eyebrow: "Welcome to Explain This",
	step: "Step 1 of 4",
	continue: "Continue to Settings",
	opening: "Opening Settings…",
	languageTitle: "Choose your language",
	languageBody: "This sets the default language for the interface and AI responses. You can change it later.",
	chinese: "中文",
	chineseHint: "使用中文界面和回答",
	english: "English",
	englishHint: "Use the app and AI in English"
};
async function openOnboardingSettings() {
	if (typeof chrome !== "undefined" && chrome?.runtime?.openOptionsPage) {
		const result = chrome.runtime.openOptionsPage();
		if (result?.then) await result;
		window.close();
		return;
	}
	window.location.href = "/settings.html?onboarding=1";
}
function useSimpleCache(enabled) {
	const cacheRef = (0, import_react.useRef)({});
	(0, import_react.useEffect)(() => {
		getStorage(["explainCache"]).then((result) => {
			const list = result.explainCache || [];
			const newCache = { ...cacheRef.current };
			list.forEach((item) => {
				if (item && item.key) newCache[item.key] = item;
			});
			cacheRef.current = newCache;
		});
	}, []);
	const normalizeKey = (text, language, speed) => {
		const base = text.trim();
		if (!language) return base;
		if (!speed) return `${base}::${language}`;
		return `${base}::${language}::${speed}`;
	};
	return {
		getCache: (0, import_react.useCallback)((text, language, speed) => {
			if (!enabled) return null;
			const key = normalizeKey(text, language, speed);
			return cacheRef.current[key] || null;
		}, [enabled]),
		upsertCache: (0, import_react.useCallback)((text, explanation, language, speed) => {
			if (!enabled) return;
			const key = normalizeKey(text, language, speed);
			cacheRef.current[key] = {
				key,
				text: text.substring(0, 200),
				explanation,
				language,
				speed,
				updatedAt: Date.now()
			};
			getStorage(["explainCache"]).then((result) => {
				const list = result.explainCache || [];
				setStorage({ explainCache: [cacheRef.current[key], ...list.filter((i) => i.key !== key)].slice(0, 100) });
			});
		}, [enabled])
	};
}
function HistoryItem({ item, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "history-item",
		onClick,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "history-item-text",
			children: item.text
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "history-item-meta",
			children: [
				(item.language || "zh").toUpperCase(),
				" · ",
				item.timestamp
			]
		})]
	});
}
function LoadingSpinner({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "loading-container",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "spinner" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "loading-text",
			children: text
		})]
	});
}
function ResultError({ message }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "result-error",
		children: message
	});
}
function ResultSuccess({ html }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		id: "resultContent",
		className: "result-content",
		dangerouslySetInnerHTML: { __html: html }
	});
}
function ResultStreaming({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stream-container",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "stream-content",
			children: text
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "stream-cursor",
			children: "▊"
		})]
	});
}
function LanguageWelcome({ language, onLanguageChange }) {
	const [opening, setOpening] = (0, import_react.useState)(false);
	const t = language === "zh" ? firstRunZh : firstRunEn;
	const handleContinue = async () => {
		setOpening(true);
		await setStorage({
			lang: language,
			onboardingStarted: true
		});
		await openOnboardingSettings();
		setOpening(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "welcome-container step-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "welcome-topline",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "welcome-brand",
					children: t.eyebrow
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "welcome-step",
					children: t.step
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "welcome-progress",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "active" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "welcome-page",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "welcome-icon",
						"aria-hidden": "true",
						children: "文"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: t.languageTitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "welcome-intro",
						children: t.languageBody
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "welcome-choice-list",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: `welcome-choice ${language === "zh" ? "selected" : ""}`,
							onClick: () => onLanguageChange("zh"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "welcome-choice-mark",
									children: "中"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.chinese }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t.chineseHint })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "welcome-radio",
									"aria-hidden": "true"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: `welcome-choice ${language === "en" ? "selected" : ""}`,
							onClick: () => onLanguageChange("en"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "welcome-choice-mark",
									children: "A"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.english }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t.englishHint })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "welcome-radio",
									"aria-hidden": "true"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "welcome-actions single",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "welcome-primary",
							onClick: handleContinue,
							disabled: opening,
							children: opening ? t.opening : t.continue
						})
					})
				]
			})
		]
	});
}
function Popup() {
	const [inputText, setInputText] = (0, import_react.useState)("");
	const [language, setLanguage] = (0, import_react.useState)("en");
	const [speed, setSpeed] = (0, import_react.useState)("fast");
	const [result, setResult] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [showResult, setShowResult] = (0, import_react.useState)(false);
	const [historyList, setHistoryList] = (0, import_react.useState)([]);
	const [langMenuOpen, setLangMenuOpen] = (0, import_react.useState)(false);
	const [onboardingRequired, setOnboardingRequired] = (0, import_react.useState)(null);
	const [pendingSelection, setPendingSelection] = (0, import_react.useState)(null);
	const [saveRecentExplanations, setSaveRecentExplanations] = (0, import_react.useState)(true);
	const [aiMode, setAiMode] = (0, import_react.useState)("builtIn");
	const [freeRemaining, setFreeRemaining] = (0, import_react.useState)(50);
	const langWrapRef = (0, import_react.useRef)(null);
	const processedSelectionIdsRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const aiServiceRef = (0, import_react.useRef)(new AIService());
	const { getCache, upsertCache } = useSimpleCache(saveRecentExplanations);
	const t = language === "zh" ? popupZh : popupEn;
	(0, import_react.useEffect)(() => {
		getStorage([
			"lang",
			"explainSpeed",
			"history",
			"pendingExplanation",
			"lastSelectedText",
			"shouldAutoFill",
			"onboardingComplete",
			"onboardingStarted",
			"apiKey",
			"geminiApiKey",
			"openaiApiKey",
			"aiMode",
			"saveRecentExplanations",
			"freeUsage"
		]).then((result) => {
			const hasSavedKey = [
				result.apiKey,
				result.geminiApiKey,
				result.openaiApiKey
			].some((key) => String(key || "").trim());
			const setupComplete = result.onboardingComplete === true || hasSavedKey;
			const nextMode = result.aiMode || (hasSavedKey ? "byok" : "builtIn");
			const shouldSaveRecent = result.saveRecentExplanations !== false;
			if (result.lang) setLanguage(result.lang);
			if (result.explainSpeed) setSpeed(result.explainSpeed);
			setAiMode(nextMode);
			setSaveRecentExplanations(shouldSaveRecent);
			if (shouldSaveRecent && result.history) setHistoryList(result.history);
			if (result.freeUsage?.date === (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)) setFreeRemaining(Number(result.freeUsage.remaining) || 0);
			if (hasSavedKey && result.onboardingComplete !== true) setStorage({
				onboardingComplete: true,
				aiMode: "byok"
			});
			if (!setupComplete && result.onboardingStarted) {
				openOnboardingSettings();
				return;
			}
			setOnboardingRequired(!setupComplete);
			if (result.pendingExplanation?.text) setPendingSelection(result.pendingExplanation);
			else if (result.shouldAutoFill && result.lastSelectedText) setPendingSelection({
				id: `legacy:${result.lastSelectedText}`,
				text: result.lastSelectedText
			});
		});
	}, []);
	(0, import_react.useEffect)(() => {
		if (typeof chrome === "undefined" || !chrome?.runtime?.sendMessage) return;
		chrome.runtime.sendMessage({ action: "activateCurrentTab" }, () => {
			chrome.runtime.lastError;
		});
	}, []);
	(0, import_react.useEffect)(() => {
		if (typeof chrome === "undefined" || !chrome?.storage?.onChanged) return void 0;
		const handleStorageChange = (changes, areaName) => {
			if (areaName !== "local") return;
			if (changes.aiMode?.newValue) setAiMode(changes.aiMode.newValue);
			if (changes.saveRecentExplanations) {
				const enabled = changes.saveRecentExplanations.newValue !== false;
				setSaveRecentExplanations(enabled);
				if (!enabled) setHistoryList([]);
			}
			if (changes.freeUsage?.newValue) setFreeRemaining(Number(changes.freeUsage.newValue.remaining) || 0);
			const request = changes.pendingExplanation?.newValue;
			if (request?.text) {
				setPendingSelection(request);
				return;
			}
			if (changes.shouldAutoFill?.newValue === true) getStorage(["lastSelectedText"]).then((result) => {
				if (!result.lastSelectedText) return;
				setPendingSelection({
					id: `legacy:${result.lastSelectedText}`,
					text: result.lastSelectedText
				});
			});
		};
		chrome.storage.onChanged.addListener(handleStorageChange);
		return () => chrome.storage.onChanged.removeListener(handleStorageChange);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!langMenuOpen) return;
		const handler = (e) => {
			if (langWrapRef.current && !langWrapRef.current.contains(e.target)) setLangMenuOpen(false);
		};
		document.addEventListener("click", handler);
		return () => document.removeEventListener("click", handler);
	}, [langMenuOpen]);
	const explainText = (0, import_react.useCallback)(async (rawText, overrideLang, overrideSpeed) => {
		const text = rawText.trim();
		if (!text) {
			setResult({
				type: "error",
				message: t.empty_input
			});
			setShowResult(true);
			return;
		}
		const currentLang = overrideLang || language;
		const currentSpeed = overrideSpeed || speed;
		const cached = getCache(text, currentLang, currentSpeed);
		if (cached?.explanation) {
			setResult({
				type: "success",
				html: cached.explanation
			});
			setShowResult(true);
			return;
		}
		setLoading(true);
		setShowResult(true);
		setResult({
			type: "streaming",
			text: ""
		});
		try {
			let streamedText = "";
			const html = await aiServiceRef.current.explainTextStream(text, {
				language: currentLang,
				speed: currentSpeed
			}, (chunk) => {
				streamedText += chunk;
				setResult({
					type: "streaming",
					text: streamedText
				});
			});
			setResult({
				type: "success",
				html
			});
			recordUsage({
				inputText: text,
				outputText: streamedText
			});
			upsertCache(text, html, currentLang, currentSpeed);
			if (saveRecentExplanations) setHistoryList((currentHistory) => {
				const newHistory = [{
					key: text,
					text: text.substring(0, 50),
					timestamp: (/* @__PURE__ */ new Date()).toLocaleString(),
					language: currentLang,
					speed: currentSpeed
				}, ...currentHistory.filter((h) => h.key !== text)].slice(0, 10);
				setStorage({ history: newHistory });
				return newHistory;
			});
		} catch (error) {
			setResult({
				type: "error",
				message: {
					QUOTA_EXCEEDED: t.quota_exceeded,
					TEXT_TOO_LONG: t.text_too_long,
					RATE_LIMITED: t.rate_limited,
					COOLDOWN_ACTIVE: t.rate_limited,
					BYOK_KEY_REQUIRED: t.key_required
				}[error.code] || t.generic_error
			});
		} finally {
			setLoading(false);
		}
	}, [
		language,
		speed,
		getCache,
		upsertCache,
		saveRecentExplanations,
		t
	]);
	const handleSubmit = (0, import_react.useCallback)(() => {
		explainText(inputText);
	}, [inputText, explainText]);
	(0, import_react.useEffect)(() => {
		if (onboardingRequired !== false || !pendingSelection?.text) return;
		const text = String(pendingSelection.text).trim();
		if (!text) return;
		const requestId = pendingSelection.id || `legacy:${text}`;
		if (processedSelectionIdsRef.current.has(requestId)) return;
		processedSelectionIdsRef.current.add(requestId);
		setPendingSelection(null);
		setInputText(text);
		setStorage({
			pendingExplanation: null,
			shouldAutoFill: false,
			lastSelectedText: ""
		});
		explainText(text);
	}, [
		onboardingRequired,
		pendingSelection,
		explainText
	]);
	if (onboardingRequired === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "popup-initializing",
		"aria-label": "Loading"
	});
	if (onboardingRequired) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageWelcome, {
		language,
		onLanguageChange: (nextLanguage) => {
			setLanguage(nextLanguage);
			setStorage({ lang: nextLanguage });
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "popup-container",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "popup-header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "popup-title",
					children: t.app_title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ai-mode-badge",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: aiMode === "builtIn" ? t.built_in : t.byok }), aiMode === "builtIn" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t.free_left.replace("{count}", freeRemaining) })]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "settings-btn",
					onClick: () => {
						if (typeof chrome !== "undefined" && chrome?.runtime?.openOptionsPage) chrome.runtime.openOptionsPage();
					},
					"aria-label": "Settings",
					title: "Settings",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 24 24",
						"aria-hidden": "true",
						className: "settings-icon",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 8.4a3.6 3.6 0 1 0 0 7.2 3.6 3.6 0 0 0 0-7.2Z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19.4 13.5c.1-.5.1-1 .1-1.5s0-1-.1-1.5l2-1.5-2-3.5-2.4 1a8.4 8.4 0 0 0-2.6-1.5L14 2.5h-4l-.4 2.5A8.4 8.4 0 0 0 7 6.5l-2.4-1-2 3.5 2 1.5c-.1.5-.1 1-.1 1.5s0 1 .1 1.5l-2 1.5 2 3.5 2.4-1a8.4 8.4 0 0 0 2.6 1.5l.4 2.5h4l.4-2.5a8.4 8.4 0 0 0 2.6-1.5l2.4 1 2-3.5-2-1.5Zm-7.4 4a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11Z" })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: "input-area",
				value: inputText,
				disabled: loading,
				onChange: (e) => setInputText(e.target.value),
				placeholder: t.input_placeholder,
				rows: 4
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "action-bar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "ask-btn",
					onClick: handleSubmit,
					disabled: loading,
					children: loading ? t.thinking : t.ask_ai
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: langWrapRef,
					className: "lang-wrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "lang-toggle",
						onClick: () => setLangMenuOpen(!langMenuOpen),
						children: language.toUpperCase()
					}), langMenuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lang-menu open",
						children: ["zh", "en"].map((lang) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `lang-option ${language === lang ? "active" : ""}`,
							onClick: () => {
								setLanguage(lang);
								setLangMenuOpen(false);
								setStorage({ lang });
							},
							children: lang.toUpperCase()
						}, lang))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "speed-bar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "speed-label",
					children: t.speed_label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "speed-toggle-group",
					children: ["fast", "detail"].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: `speed-btn ${speed === s ? "active" : ""}`,
						onClick: () => {
							setSpeed(s);
							setStorage({ explainSpeed: s });
						},
						children: t["speed_" + s]
					}, s))
				})]
			}),
			showResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "result-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "result-header",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "result-title",
						children: t.results_title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "result-header-right",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "result-close-btn",
							onClick: () => setShowResult(false),
							children: "✕"
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					result?.type === "loading" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSpinner, { text: t.thinking }),
					result?.type === "streaming" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultStreaming, { text: result.text || t.thinking }),
					result?.type === "error" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultError, { message: result.message }),
					result?.type === "success" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultSuccess, { html: result.html })
				] })]
			}),
			historyList.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "history-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "history-header",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "history-title",
						children: t.history_title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "clear-history-btn",
						onClick: () => {
							setHistoryList([]);
							setStorage({ history: [] });
						},
						children: t.clear_history
					})]
				}), historyList.slice(0, 5).map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryItem, {
					item,
					onClick: () => {
						setInputText(item.text);
						setLanguage(item.language || "zh");
						setSpeed(item.speed || "fast");
						explainText(item.text, item.language || "zh", item.speed || "fast");
					}
				}, i))]
			})
		]
	});
}
//#endregion
//#region src/popup/main.jsx
import_client.createRoot(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Popup, {}) }));
//#endregion
