import { c as __toESM, i as normalizeUsageStats, n as getLastSevenDays, o as require_client, r as getUsageStats, s as require_react, t as require_jsx_runtime } from "./jsx-runtime-BBj45LBy.js";
//#region src/settingStyle.css
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_client = /* @__PURE__ */ __toESM(require_client(), 1);
//#endregion
//#region src/settings/settings.jsx
var import_jsx_runtime = require_jsx_runtime();
var hasExtensionStorage = () => typeof chrome !== "undefined" && chrome?.storage?.local;
var getStorage = (keys) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve({});
		return;
	}
	chrome.storage.local.get(keys, resolve);
});
var setStorage = (values) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve();
		return;
	}
	chrome.storage.local.set(values, resolve);
});
var removeStorage = (keys) => new Promise((resolve) => {
	if (!hasExtensionStorage()) {
		resolve();
		return;
	}
	chrome.storage.local.remove(keys, resolve);
});
var providers = [
	{
		id: "openai",
		name: "OpenAI",
		storageKey: "openaiApiKey",
		keyUrl: "https://platform.openai.com/api-keys",
		permissionOrigin: "https://api.openai.com/*",
		placeholder: "sk-..."
	},
	{
		id: "gemini",
		name: "Gemini",
		storageKey: "geminiApiKey",
		keyUrl: "https://aistudio.google.com/app/apikey",
		permissionOrigin: "https://generativelanguage.googleapis.com/*",
		placeholder: "AIza..."
	},
	{
		id: "deepseek",
		name: "DeepSeek",
		storageKey: "apiKey",
		keyUrl: "https://platform.deepseek.com/api_keys",
		permissionOrigin: "https://api.deepseek.com/*",
		placeholder: "sk-..."
	}
];
var copy = {
	zh: {
		settings: "设置",
		close: "关闭",
		github: "GitHub 项目",
		builtInTitle: "内置免费 AI",
		builtInBadge: "默认",
		builtInBody: "安装后直接使用，无需 API Key。每天可获得 50 次 AI 解释。",
		modeLabel: "AI 模式",
		builtInMode: "内置 AI",
		builtInModeHint: "每天 50 次免费解释，无需配置",
		byokMode: "使用自己的 API Key",
		byokModeHint: "更高额度和更多控制，费用由你的服务商账户承担",
		today: "今日免费额度",
		resetsDaily: "额度每天自动恢复；后端记录才是最终依据。",
		preferences: "解释偏好",
		style: "默认解释风格",
		concise: "简明",
		detailed: "详细",
		saveRecent: "保存最近的解释",
		saveRecentHint: "在此浏览器本地保存最多 10 条历史和 100 条缓存。关闭后会清除已有内容。",
		privacyTitle: "隐私",
		privacyBody: "只处理你主动提交解释的文本。免费模式会经由 Explain This 后端转发，原文不在我们的应用数据库中持久保存。",
		privacyLink: "查看完整隐私政策",
		sitesTitle: "已启用网站",
		sitesBody: "Explain This 默认仅在你主动点击扩展或使用快捷键的页面运行。你也可以允许它在指定网站自动显示划词按钮。",
		sitePlaceholder: "example.com",
		addSite: "允许网站",
		noSites: "还没有永久允许的网站。",
		remove: "移除",
		siteAdded: "网站已启用；已打开的匹配页面也会立即生效。",
		siteRemoved: "网站权限已移除。",
		invalidSite: "请输入有效的网站域名。",
		permissionDenied: "未授予网站权限。",
		advanced: "高级选项",
		advancedIntro: "使用自己的 API Key 以获得更高额度或直接控制服务商。普通用户不需要这里的任何设置。",
		provider: "AI 服务商",
		apiKey: "API Key",
		getKey: "获取 API Key",
		saveAndUse: "保存并使用此 Key",
		test: "测试连接",
		clear: "清除 Key",
		keyLocal: "Key 仅保存在此浏览器的扩展本地存储中，并直接发送给你选择的服务商。",
		keyRequired: "请先输入 API Key。",
		keySaved: "API Key 已保存，已切换到自带 Key 模式。",
		keyCleared: "API Key 已清除，已切换回内置 AI。",
		testing: "正在测试连接…",
		testSuccess: "连接成功。",
		testFailed: "连接失败，请检查 Key 和网络后重试。",
		providerPermissionDenied: "需要允许连接此 AI 服务商才能使用自带 Key。",
		localUsage: "使用统计",
		lastSevenDays: "最近 7 天查询次数",
		sevenDayTotal: "7 天共 {count} 次",
		queries: "{count} 次查询",
		noQueries: "最近 7 天还没有查询记录",
		onboardingEyebrow: "Explain This 新手设置",
		onboardingStep: "第 {current} 步，共 5 步",
		back: "返回",
		continue: "继续",
		styleTitle: "你喜欢怎样的解释？",
		styleBody: "先选择默认详略，之后可以在 popup 中随时切换。",
		privacyOnboardingTitle: "数据如何传输？",
		privacyOnboardingBody: "只有你主动提交的文本会被处理。扩展不会发送当前页面网址、浏览历史或网页中的其他内容。网络请求会携带 IP；应用只保存其加盐哈希和请求计数，用于限额与滥用保护。",
		freeFlowTitle: "免费模式的数据路径",
		freeFlowBody: "扩展发送选中文本、回答语言、解释详略和随机安装 ID 到 Explain This 后端；后端执行额度与滥用保护，再将解释请求转发给 AI 服务商。原文不会保存在我们的应用数据库中。",
		byokFlowTitle: "使用自己的 API Key",
		byokFlowBody: "请求会从扩展直接发送到你选择的 AI 服务商，不经过 Explain This 后端；API Key 仅从此浏览器本地读取，用于向该服务商认证。",
		selectedTextNode: "你选择的文本",
		backendNode: "Explain This 后端",
		providerNode: "AI 服务商",
		resultNode: "解释结果",
		ownKeyShortcut: "I have my own API Key",
		activationTitle: "先激活，再开始划词",
		activationBody: "Chrome 只会在你主动点击扩展后授予当前页面访问权限。首次在普通网页使用时，请先点击一次浏览器工具栏里的 Explain This 图标。",
		clickOnceTitle: "普通网页：点击一次",
		clickOnceBody: "点击插件后，当前标签页会立即激活划词按钮。",
		firstSitesTitle: "常用网站：加入白名单",
		firstSitesBody: "加入后，这些网站及其子域名会自动启用，无需每次先点插件。",
		addFirstSite: "添加网站",
		activationContinue: "继续",
		readyTitle: "准备好了",
		readyBody: "每天 50 次免费解释，无需 API Key。先在网页上点击一次插件，之后选中文字即可看到 Explain this。",
		start: "开始使用"
	},
	en: {
		settings: "Settings",
		close: "Close",
		github: "GitHub Repository",
		builtInTitle: "Free built-in AI",
		builtInBadge: "Default",
		builtInBody: "Works immediately after installation. No API key required. Includes 50 AI explanations each day.",
		modeLabel: "AI mode",
		builtInMode: "Built-in AI",
		builtInModeHint: "50 free explanations a day, with no setup",
		byokMode: "Use your own API key",
		byokModeHint: "Higher limits and more control, billed by your provider",
		today: "Free usage today",
		resetsDaily: "The allowance resets daily. The backend record is authoritative.",
		preferences: "Explanation preferences",
		style: "Default explanation style",
		concise: "Concise",
		detailed: "Detailed",
		saveRecent: "Save recent explanations",
		saveRecentHint: "Stores up to 10 history items and 100 cached explanations locally. Turning it off clears both.",
		privacyTitle: "Privacy",
		privacyBody: "Only text you explicitly submit is processed. In free mode it passes through the Explain This backend; the original text is not persisted in our application database.",
		privacyLink: "Read the full Privacy Policy",
		sitesTitle: "Enabled sites",
		sitesBody: "By default, Explain This runs only after you click the extension or use its shortcut. You can also allow the selection button to appear automatically on specific sites.",
		sitePlaceholder: "example.com",
		addSite: "Allow site",
		noSites: "No sites have permanent access yet.",
		remove: "Remove",
		siteAdded: "Site enabled. Open matching pages are active now.",
		siteRemoved: "Site permission removed.",
		invalidSite: "Enter a valid website domain.",
		permissionDenied: "Site permission was not granted.",
		advanced: "Advanced",
		advancedIntro: "Bring your own API key for higher limits or direct provider control. Most people do not need anything in this section.",
		provider: "AI provider",
		apiKey: "API key",
		getKey: "Get an API key",
		saveAndUse: "Save and use this key",
		test: "Test connection",
		clear: "Clear key",
		keyLocal: "Your key stays in this browser’s local extension storage and is sent directly to the provider you choose.",
		keyRequired: "Enter an API key first.",
		keySaved: "API key saved. Bring Your Own Key mode is now active.",
		keyCleared: "API key cleared. Switched back to Built-in AI.",
		testing: "Testing connection…",
		testSuccess: "Connection successful.",
		testFailed: "Connection failed. Check the key and your connection, then try again.",
		providerPermissionDenied: "Provider access is required to use your own key.",
		localUsage: "Usage",
		lastSevenDays: "Queries in the last 7 days",
		sevenDayTotal: "{count} queries over 7 days",
		queries: "{count} queries",
		noQueries: "No queries recorded in the last 7 days",
		onboardingEyebrow: "Explain This setup",
		onboardingStep: "Step {current} of 5",
		back: "Back",
		continue: "Continue",
		styleTitle: "How detailed should explanations be?",
		styleBody: "Choose a default style. You can switch it anytime in the popup.",
		privacyOnboardingTitle: "Where does your data go?",
		privacyOnboardingBody: "Only text you explicitly submit is processed. The extension does not send the current page URL, browsing history, or other page content. Network requests include an IP address; the app stores only salted hashes and request counters for quota and abuse protection.",
		freeFlowTitle: "Built-in AI data path",
		freeFlowBody: "The extension sends the selected text, response language, explanation style, and a random installation ID to the Explain This backend. The backend enforces quotas and abuse protection, then relays the explanation request to an AI provider. The original text is not stored in our application database.",
		byokFlowTitle: "Using your own API key",
		byokFlowBody: "Requests go directly from the extension to your chosen AI provider and bypass the Explain This backend. Your API key is read from local extension storage only to authenticate with that provider.",
		selectedTextNode: "Selected text",
		backendNode: "Explain This backend",
		providerNode: "AI provider",
		resultNode: "Explanation",
		ownKeyShortcut: "I have my own API Key",
		activationTitle: "Activate once, then highlight",
		activationBody: "Chrome grants access to the current page only after you interact with the extension. On a regular site, click the Explain This toolbar icon once before your first selection.",
		clickOnceTitle: "Regular pages: click once",
		clickOnceBody: "Clicking the extension immediately activates the selection button in the current tab.",
		firstSitesTitle: "Frequent sites: add to allowlist",
		firstSitesBody: "Allowed sites and their subdomains activate automatically, so no toolbar click is needed.",
		addFirstSite: "Add site",
		activationContinue: "Continue",
		readyTitle: "You’re ready",
		readyBody: "Get 50 free explanations every day with no API key. Click the extension once on a page, then highlight text to reveal Explain this.",
		start: "Start explaining"
	}
};
function format(text, values) {
	return Object.entries(values).reduce((result, [key, value]) => result.replace(`{${key}}`, value), text);
}
function getPrivacyUrl() {
	if (typeof chrome !== "undefined" && chrome?.runtime?.getURL) return chrome.runtime.getURL("privacy-policy.html");
	return "/privacy-policy.html";
}
function requestOptionalOrigins(origins) {
	return new Promise((resolve) => {
		if (typeof chrome === "undefined" || !chrome?.permissions?.request) {
			resolve(false);
			return;
		}
		chrome.permissions.request({ origins }, (granted) => {
			if (chrome.runtime.lastError) {
				resolve(false);
				return;
			}
			resolve(Boolean(granted));
		});
	});
}
function removeOptionalOrigins(origins) {
	return new Promise((resolve) => {
		if (typeof chrome === "undefined" || !chrome?.permissions?.remove) {
			resolve(false);
			return;
		}
		chrome.permissions.remove({ origins }, (removed) => resolve(Boolean(removed)));
	});
}
function syncEnabledSites() {
	return new Promise((resolve) => {
		if (typeof chrome === "undefined" || !chrome?.runtime?.sendMessage) {
			resolve();
			return;
		}
		chrome.runtime.sendMessage({ action: "syncEnabledSites" }, () => {
			chrome.runtime.lastError;
			resolve();
		});
	});
}
function normalizeSite(value) {
	const trimmed = String(value || "").trim().toLowerCase();
	if (!trimmed || /[\s/]/.test(trimmed.replace(/^https?:\/\//, ""))) return null;
	try {
		const url = new URL(trimmed.includes("://") ? trimmed : `https://${trimmed}`);
		if (!["http:", "https:"].includes(url.protocol) || !url.hostname) return null;
		const hostname = url.hostname.replace(/^www\./, "");
		const permissionHost = hostname !== "localhost" && !/^\d{1,3}(?:\.\d{1,3}){3}$/.test(hostname) && !hostname.startsWith("[") ? `*.${hostname}` : hostname;
		return {
			hostname,
			origins: [`https://${permissionHost}/*`, `http://${permissionHost}/*`]
		};
	} catch {
		return null;
	}
}
async function testProviderConnection(provider, apiKey) {
	let response;
	if (provider === "gemini") response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"x-goog-api-key": apiKey
		},
		body: JSON.stringify({
			contents: [{
				role: "user",
				parts: [{ text: "Reply with OK." }]
			}],
			generationConfig: {
				maxOutputTokens: 32,
				temperature: 0
			}
		})
	});
	else response = await fetch(provider === "openai" ? "https://api.openai.com/v1/models" : "https://api.deepseek.com/v1/models", { headers: { Authorization: `Bearer ${apiKey}` } });
	if (!response.ok) throw new Error("connection_failed");
}
function Section({ id, title, children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: `section ${className}`,
		id,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "section-title",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: title })
		}), children]
	});
}
function UsageChart({ stats, lang, labels }) {
	const days = (0, import_react.useMemo)(() => getLastSevenDays(stats), [stats]);
	const width = 640;
	const height = 220;
	const padding = {
		top: 20,
		right: 18,
		bottom: 26,
		left: 32
	};
	const chartWidth = width - padding.left - padding.right;
	const chartHeight = height - padding.top - padding.bottom;
	const maximum = Math.max(1, ...days.map((day) => day.requests));
	const roundedMaximum = maximum <= 5 ? maximum : Math.ceil(maximum / 5) * 5;
	const points = days.map((day, index) => {
		const x = padding.left + chartWidth * index / (days.length - 1);
		const y = padding.top + chartHeight - day.requests / roundedMaximum * chartHeight;
		return {
			...day,
			x,
			y
		};
	});
	const linePath = points.map((point, index) => `${index === 0 ? "M" : "L"} ${point.x} ${point.y}`).join(" ");
	const areaPath = `${linePath} L ${points.at(-1).x} ${padding.top + chartHeight} L ${points[0].x} ${padding.top + chartHeight} Z`;
	const total = days.reduce((sum, day) => sum + day.requests, 0);
	const locale = lang === "zh" ? "zh-CN" : "en-US";
	const weekdayFormatter = new Intl.DateTimeFormat(locale, { weekday: "short" });
	const pointsWithLabels = points.map((point) => ({
		...point,
		label: weekdayFormatter.format(/* @__PURE__ */ new Date(`${point.date}T12:00:00`))
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "usage-chart",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "usage-chart-heading",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: labels.lastSevenDays }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: total === 0 ? labels.noQueries : format(labels.sevenDayTotal, { count: total }) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: total })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "usage-chart-plot",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "usage-y-label top",
					children: roundedMaximum
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "usage-y-label bottom",
					children: "0"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: `0 0 ${width} ${height}`,
					role: "img",
					"aria-label": format(labels.sevenDayTotal, { count: total }),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: labels.lastSevenDays }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
							id: "usage-area-fill",
							x1: "0",
							y1: "0",
							x2: "0",
							y2: "1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "0%",
								stopColor: "#4d91e6",
								stopOpacity: "0.28"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "100%",
								stopColor: "#4d91e6",
								stopOpacity: "0.02"
							})]
						}) }),
						[
							0,
							.5,
							1
						].map((fraction) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							className: "usage-grid-line",
							x1: padding.left,
							x2: width - padding.right,
							y1: padding.top + chartHeight * fraction,
							y2: padding.top + chartHeight * fraction
						}, fraction)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							className: "usage-area",
							d: areaPath
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							className: "usage-line",
							d: linePath,
							pathLength: "1"
						}),
						pointsWithLabels.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							className: "usage-point",
							cx: point.x,
							cy: point.y,
							r: "5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: format(labels.queries, { count: point.requests }) })
						}, point.date)),
						pointsWithLabels.map((point, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							className: "usage-x-label",
							x: point.x,
							y: height - 3,
							textAnchor: index === 0 ? "start" : index === pointsWithLabels.length - 1 ? "end" : "middle",
							children: point.label
						}, `${point.date}-label`))
					]
				})
			]
		})]
	});
}
function SetupOnboarding({ lang, initialSpeed, initialEnabledSites, onComplete, onEnabledSitesChange, onOpenAdvanced }) {
	const [step, setStep] = (0, import_react.useState)(1);
	const [speed, setSpeed] = (0, import_react.useState)(initialSpeed || "fast");
	const [firstSiteInput, setFirstSiteInput] = (0, import_react.useState)("");
	const [firstSites, setFirstSites] = (0, import_react.useState)(initialEnabledSites || []);
	const [firstSiteStatus, setFirstSiteStatus] = (0, import_react.useState)({
		message: "",
		type: ""
	});
	const t = copy[lang];
	const overallStep = step + 1;
	const completeOnboarding = async (openAdvanced = false) => {
		await setStorage({
			aiMode: "builtIn",
			explainSpeed: speed,
			saveRecentExplanations: true,
			onboardingComplete: true,
			onboardingStarted: false
		});
		if (openAdvanced) {
			onOpenAdvanced(speed);
			return;
		}
		onComplete(speed);
	};
	const handleAddFirstSite = async () => {
		const site = normalizeSite(firstSiteInput);
		if (!site) {
			setFirstSiteStatus({
				message: t.invalidSite,
				type: "error"
			});
			return;
		}
		if (!await requestOptionalOrigins(site.origins)) {
			setFirstSiteStatus({
				message: t.permissionDenied,
				type: "error"
			});
			return;
		}
		const nextSites = [...firstSites.filter((item) => item.hostname !== site.hostname), site].sort((left, right) => left.hostname.localeCompare(right.hostname));
		setFirstSites(nextSites);
		onEnabledSitesChange(nextSites);
		setFirstSiteInput("");
		await setStorage({ enabledSites: nextSites });
		await syncEnabledSites();
		setFirstSiteStatus({
			message: t.siteAdded,
			type: "success"
		});
	};
	const handleRemoveFirstSite = async (site) => {
		await removeOptionalOrigins(site.origins || []);
		const nextSites = firstSites.filter((item) => item.hostname !== site.hostname);
		setFirstSites(nextSites);
		onEnabledSitesChange(nextSites);
		await setStorage({ enabledSites: nextSites });
		await syncEnabledSites();
		setFirstSiteStatus({
			message: t.siteRemoved,
			type: "success"
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "settings-onboarding-shell",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "settings-onboarding-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "settings-onboarding-topline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.onboardingEyebrow }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: format(t.onboardingStep, { current: overallStep }) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "settings-onboarding-progress",
					"aria-hidden": "true",
					children: [
						1,
						2,
						3,
						4,
						5
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: item <= overallStep ? "active" : "" }, item))
				}),
				step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "settings-onboarding-page",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "settings-onboarding-icon",
							children: "≡"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: t.styleTitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "settings-onboarding-intro",
							children: t.styleBody
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "settings-choice-grid speed-choices",
							children: [[
								"fast",
								"⚡",
								t.concise
							], [
								"detail",
								"☷",
								t.detailed
							]].map(([value, icon, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: `settings-choice ${speed === value ? "selected" : ""}`,
								onClick: () => setSpeed(value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "settings-choice-icon",
										children: icon
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: label }) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "settings-choice-radio" })
								]
							}, value))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "settings-onboarding-actions single",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "settings-onboarding-primary",
								onClick: () => setStep(2),
								children: t.continue
							})
						})
					]
				}),
				step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "settings-onboarding-page compact",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "settings-onboarding-icon notice",
							children: "→"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: t.privacyOnboardingTitle }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-data-route",
							"aria-label": t.freeFlowTitle,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.selectedTextNode }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									"aria-hidden": "true",
									children: "→"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.backendNode }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									"aria-hidden": "true",
									children: "→"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.providerNode }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									"aria-hidden": "true",
									children: "→"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.resultNode })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-principle-box",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.privacyTitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.privacyOnboardingBody })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-principle-box",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.freeFlowTitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.freeFlowBody })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-principle-box byok",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.byokFlowTitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.byokFlowBody })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-onboarding-link-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "settings-onboarding-link",
								href: getPrivacyUrl(),
								target: "_blank",
								rel: "noreferrer",
								children: [t.privacyLink, " ↗"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "settings-own-key-link",
								type: "button",
								onClick: () => completeOnboarding(true),
								children: [t.ownKeyShortcut, " →"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-onboarding-actions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "settings-onboarding-secondary",
								onClick: () => setStep(1),
								children: t.back
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "settings-onboarding-primary",
								onClick: () => setStep(3),
								children: t.continue
							})]
						})
					]
				}),
				step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "settings-onboarding-page compact activation-page",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "settings-onboarding-icon activation",
							children: "1×"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: t.activationTitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "settings-onboarding-intro",
							children: t.activationBody
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "activation-note",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "↗" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.clickOnceTitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.clickOnceBody })] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "first-sites-block",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.firstSitesTitle }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.firstSitesBody }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "site-add-row onboarding-site-add",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										value: firstSiteInput,
										placeholder: t.sitePlaceholder,
										onChange: (event) => {
											setFirstSiteInput(event.target.value);
											setFirstSiteStatus({
												message: "",
												type: ""
											});
										},
										onKeyDown: (event) => {
											if (event.key === "Enter") handleAddFirstSite();
										}
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "primary-btn",
										onClick: handleAddFirstSite,
										children: t.addFirstSite
									})]
								}),
								firstSites.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "site-list onboarding-site-list",
									children: firstSites.map((site) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "site-row",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "site-dot" }), site.hostname] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => handleRemoveFirstSite(site),
											children: t.remove
										})]
									}, site.hostname))
								}),
								firstSiteStatus.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `status ${firstSiteStatus.type}`,
									children: firstSiteStatus.message
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-onboarding-actions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "settings-onboarding-secondary",
								onClick: () => setStep(2),
								children: t.back
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "settings-onboarding-primary",
								onClick: () => setStep(4),
								children: t.activationContinue
							})]
						})
					]
				}),
				step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "settings-onboarding-page ready-page",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "settings-ready-icon",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/icon128.png",
								alt: ""
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: t.readyTitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "settings-onboarding-intro",
							children: t.readyBody
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "free-plan-callout",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang === "zh" ? "次免费解释 / 天" : "free explanations / day" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "settings-onboarding-actions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "settings-onboarding-secondary",
								onClick: () => setStep(3),
								children: t.back
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "settings-onboarding-primary",
								onClick: () => completeOnboarding(false),
								children: t.start
							})]
						})
					]
				})
			]
		})
	});
}
function SettingsPage() {
	const [lang, setLang] = (0, import_react.useState)("zh");
	const [speed, setSpeed] = (0, import_react.useState)("fast");
	const [aiMode, setAiMode] = (0, import_react.useState)("builtIn");
	const [saveRecent, setSaveRecent] = (0, import_react.useState)(true);
	const [provider, setProvider] = (0, import_react.useState)("openai");
	const [apiKey, setApiKey] = (0, import_react.useState)("");
	const [savedKeys, setSavedKeys] = (0, import_react.useState)({});
	const [enabledSites, setEnabledSites] = (0, import_react.useState)([]);
	const [siteInput, setSiteInput] = (0, import_react.useState)("");
	const [siteStatus, setSiteStatus] = (0, import_react.useState)({
		message: "",
		type: ""
	});
	const [keyStatus, setKeyStatus] = (0, import_react.useState)({
		message: "",
		type: ""
	});
	const [testing, setTesting] = (0, import_react.useState)(false);
	const [usageStats, setUsageStats] = (0, import_react.useState)(normalizeUsageStats());
	const [freeUsage, setFreeUsage] = (0, import_react.useState)(null);
	const [onboardingRequired, setOnboardingRequired] = (0, import_react.useState)(null);
	const [providerMenuOpen, setProviderMenuOpen] = (0, import_react.useState)(false);
	const [advancedOpen, setAdvancedOpen] = (0, import_react.useState)(false);
	const advancedPanelRef = (0, import_react.useRef)(null);
	const providerMenuRef = (0, import_react.useRef)(null);
	const t = copy[lang];
	const selectedProvider = (0, import_react.useMemo)(() => providers.find((item) => item.id === provider) || providers[0], [provider]);
	(0, import_react.useEffect)(() => {
		getStorage([
			"lang",
			"explainSpeed",
			"aiMode",
			"saveRecentExplanations",
			"provider",
			"apiKey",
			"geminiApiKey",
			"openaiApiKey",
			"enabledSites",
			"freeUsage",
			"onboardingComplete"
		]).then((result) => {
			const keys = {
				apiKey: result.apiKey || "",
				geminiApiKey: result.geminiApiKey || "",
				openaiApiKey: result.openaiApiKey || ""
			};
			const hasSavedKey = Object.values(keys).some((key) => String(key).trim());
			const nextProvider = result.provider || "openai";
			const providerConfig = providers.find((item) => item.id === nextProvider) || providers[0];
			setLang(result.lang || "zh");
			setSpeed(result.explainSpeed || "fast");
			setAiMode(result.aiMode || (hasSavedKey ? "byok" : "builtIn"));
			setSaveRecent(result.saveRecentExplanations !== false);
			setProvider(nextProvider);
			setSavedKeys(keys);
			setApiKey(keys[providerConfig.storageKey] || "");
			setEnabledSites(Array.isArray(result.enabledSites) ? result.enabledSites : []);
			setFreeUsage(result.freeUsage || null);
			setOnboardingRequired(!(result.onboardingComplete === true || hasSavedKey));
			if (hasSavedKey && result.onboardingComplete !== true) setStorage({
				onboardingComplete: true,
				onboardingStarted: false,
				aiMode: "byok"
			});
		});
	}, []);
	(0, import_react.useEffect)(() => {
		getUsageStats().then(setUsageStats);
		if (typeof chrome === "undefined" || !chrome?.storage?.onChanged) return void 0;
		const handleStorageChange = (changes, areaName) => {
			if (areaName !== "local") return;
			if (changes.usageStats) setUsageStats(normalizeUsageStats(changes.usageStats.newValue));
			if (changes.freeUsage) setFreeUsage(changes.freeUsage.newValue);
		};
		chrome.storage.onChanged.addListener(handleStorageChange);
		return () => chrome.storage.onChanged.removeListener(handleStorageChange);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!providerMenuOpen) return void 0;
		const handleOutsidePointer = (event) => {
			if (!providerMenuRef.current?.contains(event.target)) setProviderMenuOpen(false);
		};
		document.addEventListener("pointerdown", handleOutsidePointer);
		return () => document.removeEventListener("pointerdown", handleOutsidePointer);
	}, [providerMenuOpen]);
	const currentFreeUsage = freeUsage?.date === (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) ? freeUsage : {
		limit: 50,
		remaining: 50
	};
	const freeLimit = Number(currentFreeUsage.limit) || 50;
	const freeRemaining = Math.max(0, Number(currentFreeUsage.remaining) || 0);
	const freeUsed = Math.max(0, freeLimit - freeRemaining);
	const handleProviderChange = (nextProvider) => {
		const config = providers.find((item) => item.id === nextProvider) || providers[0];
		setProvider(nextProvider);
		setApiKey(savedKeys[config.storageKey] || "");
		setProviderMenuOpen(false);
		setKeyStatus({
			message: "",
			type: ""
		});
		setStorage({ provider: nextProvider });
	};
	const handleModeChange = (nextMode) => {
		setAiMode(nextMode);
		setStorage({ aiMode: nextMode });
		if (nextMode !== "byok" || !advancedPanelRef.current) return;
		setAdvancedOpen(true);
		requestAnimationFrame(() => {
			const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
			advancedPanelRef.current?.scrollIntoView({
				behavior: reduceMotion ? "auto" : "smooth",
				block: "start"
			});
		});
	};
	const handleSaveRecentChange = async (enabled) => {
		setSaveRecent(enabled);
		if (enabled) {
			await setStorage({ saveRecentExplanations: true });
			return;
		}
		await setStorage({
			saveRecentExplanations: false,
			history: [],
			explainCache: []
		});
	};
	const handleSaveKey = async () => {
		const normalized = apiKey.trim();
		if (!normalized) {
			setKeyStatus({
				message: t.keyRequired,
				type: "error"
			});
			return;
		}
		if (!await requestOptionalOrigins([selectedProvider.permissionOrigin])) {
			setKeyStatus({
				message: t.providerPermissionDenied,
				type: "error"
			});
			return;
		}
		await setStorage({
			[selectedProvider.storageKey]: normalized,
			provider,
			aiMode: "byok"
		});
		setSavedKeys((current) => ({
			...current,
			[selectedProvider.storageKey]: normalized
		}));
		setApiKey(normalized);
		setAiMode("byok");
		setKeyStatus({
			message: t.keySaved,
			type: "success"
		});
	};
	const handleClearKey = async () => {
		await removeStorage(selectedProvider.storageKey);
		await removeOptionalOrigins([selectedProvider.permissionOrigin]);
		setSavedKeys((current) => ({
			...current,
			[selectedProvider.storageKey]: ""
		}));
		setApiKey("");
		setAiMode("builtIn");
		await setStorage({ aiMode: "builtIn" });
		setKeyStatus({
			message: t.keyCleared,
			type: "success"
		});
	};
	const handleTestConnection = async () => {
		const normalized = apiKey.trim();
		if (!normalized) {
			setKeyStatus({
				message: t.keyRequired,
				type: "error"
			});
			return;
		}
		if (!await requestOptionalOrigins([selectedProvider.permissionOrigin])) {
			setKeyStatus({
				message: t.providerPermissionDenied,
				type: "error"
			});
			return;
		}
		setTesting(true);
		setKeyStatus({
			message: t.testing,
			type: "info"
		});
		try {
			await testProviderConnection(provider, normalized);
			setKeyStatus({
				message: t.testSuccess,
				type: "success"
			});
		} catch {
			setKeyStatus({
				message: t.testFailed,
				type: "error"
			});
		} finally {
			setTesting(false);
		}
	};
	const handleAddSite = async () => {
		const site = normalizeSite(siteInput);
		if (!site) {
			setSiteStatus({
				message: t.invalidSite,
				type: "error"
			});
			return;
		}
		if (!await requestOptionalOrigins(site.origins)) {
			setSiteStatus({
				message: t.permissionDenied,
				type: "error"
			});
			return;
		}
		const nextSites = [...enabledSites.filter((item) => item.hostname !== site.hostname), site].sort((left, right) => left.hostname.localeCompare(right.hostname));
		setEnabledSites(nextSites);
		setSiteInput("");
		await setStorage({ enabledSites: nextSites });
		await syncEnabledSites();
		setSiteStatus({
			message: t.siteAdded,
			type: "success"
		});
	};
	const handleRemoveSite = async (site) => {
		await removeOptionalOrigins(site.origins || []);
		const nextSites = enabledSites.filter((item) => item.hostname !== site.hostname);
		setEnabledSites(nextSites);
		await setStorage({ enabledSites: nextSites });
		await syncEnabledSites();
		setSiteStatus({
			message: t.siteRemoved,
			type: "success"
		});
	};
	const handleClose = () => {
		if (typeof chrome !== "undefined" && chrome?.tabs?.getCurrent && chrome?.tabs?.remove) {
			chrome.tabs.getCurrent((tab) => {
				if (tab?.id) chrome.tabs.remove(tab.id);
				else window.close();
			});
			return;
		}
		window.close();
	};
	if (onboardingRequired === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "settings-initializing",
		"aria-label": "Loading"
	});
	if (onboardingRequired) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetupOnboarding, {
		lang,
		initialSpeed: speed,
		initialEnabledSites: enabledSites,
		onEnabledSitesChange: setEnabledSites,
		onComplete: (nextSpeed) => {
			setSpeed(nextSpeed);
			setAiMode("builtIn");
			setSaveRecent(true);
			setOnboardingRequired(false);
		},
		onOpenAdvanced: (nextSpeed) => {
			setSpeed(nextSpeed);
			setAiMode("builtIn");
			setSaveRecent(true);
			setAdvancedOpen(true);
			setOnboardingRequired(false);
			requestAnimationFrame(() => {
				requestAnimationFrame(() => {
					advancedPanelRef.current?.scrollIntoView({
						behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
						block: "start"
					});
				});
			});
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "settings-page",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "top-bar",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: t.settings }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "top-actions",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "github-link",
						href: "https://github.com/HeyiCAo/ExplainThis",
						target: "_blank",
						rel: "noreferrer",
						children: [t.github, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: "↗"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "lang-switch",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setLang("zh");
								setStorage({ lang: "zh" });
							},
							className: lang === "zh" ? "active" : "",
							children: "中"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setLang("en");
								setStorage({ lang: "en" });
							},
							className: lang === "en" ? "active" : "",
							children: "EN"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "close-btn",
						onClick: handleClose,
						children: t.close
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "settings-layout",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					id: "builtInAI",
					title: t.builtInTitle,
					className: "hero-section",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "built-in-intro",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "plan-badge",
								children: t.builtInBadge
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.builtInBody })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t.modeLabel }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mode-choice-grid",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: `mode-choice ${aiMode === "builtIn" ? "selected" : ""}`,
								onClick: () => handleModeChange("builtIn"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mode-choice-icon",
										children: "✦"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.builtInMode }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t.builtInModeHint })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "settings-choice-radio" })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: `mode-choice ${aiMode === "byok" ? "selected" : ""}`,
								onClick: () => handleModeChange("byok"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mode-choice-icon",
										children: "⌁"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.byokMode }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t.byokModeHint })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "settings-choice-radio" })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "quota-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.today }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
									freeUsed,
									" / ",
									freeLimit
								] })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "quota-track",
									"aria-label": `${freeUsed} / ${freeLimit}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { width: `${Math.min(100, freeUsed / freeLimit * 100)}%` } })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t.resetsDaily })
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					id: "preferences",
					title: t.preferences,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { children: t.style }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "segmented-setting",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: speed === "fast" ? "active" : "",
								onClick: () => {
									setSpeed("fast");
									setStorage({ explainSpeed: "fast" });
								},
								children: t.concise
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: speed === "detail" ? "active" : "",
								onClick: () => {
									setSpeed("detail");
									setStorage({ explainSpeed: "detail" });
								},
								children: t.detailed
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "toggle-setting",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.saveRecent }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: t.saveRecentHint })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: saveRecent,
								onChange: (event) => handleSaveRecentChange(event.target.checked)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "privacy-note",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: t.privacyTitle }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.privacyBody }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: getPrivacyUrl(),
									target: "_blank",
									rel: "noreferrer",
									children: [t.privacyLink, " ↗"]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					id: "enabledSites",
					title: t.sitesTitle,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "section-copy",
							children: t.sitesBody
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "site-add-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								value: siteInput,
								placeholder: t.sitePlaceholder,
								onChange: (event) => setSiteInput(event.target.value),
								onKeyDown: (event) => {
									if (event.key === "Enter") handleAddSite();
								}
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "primary-btn",
								onClick: handleAddSite,
								children: t.addSite
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "site-list",
							children: [enabledSites.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "empty-sites",
								children: t.noSites
							}), enabledSites.map((site) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "site-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "site-dot" }), site.hostname] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => handleRemoveSite(site),
									children: t.remove
								})]
							}, site.hostname))]
						}),
						siteStatus.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `status ${siteStatus.type}`,
							children: siteStatus.message
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					id: "usage",
					title: t.localUsage,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsageChart, {
						stats: usageStats,
						lang,
						labels: t
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: `advanced-panel ${advancedOpen ? "is-open" : ""}`,
					ref: advancedPanelRef,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "advanced-summary",
						"aria-expanded": advancedOpen,
						onClick: () => setAdvancedOpen((current) => !current),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.advanced })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "advanced-collapse",
						"aria-hidden": !advancedOpen,
						inert: !advancedOpen,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "advanced-content",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.advancedIntro }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "advanced-form-grid",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "advanced-field",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "advanced-field-label",
											children: t.provider
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "custom-provider-select",
											ref: providerMenuRef,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												className: "custom-provider-trigger",
												"aria-haspopup": "listbox",
												"aria-expanded": providerMenuOpen,
												onClick: () => setProviderMenuOpen((current) => !current),
												onKeyDown: (event) => {
													if (event.key === "Escape") setProviderMenuOpen(false);
												},
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `custom-provider-mark ${selectedProvider.id}`,
														children: selectedProvider.name.charAt(0)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: selectedProvider.name }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "custom-provider-chevron",
														"aria-hidden": "true",
														children: "⌄"
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: `custom-provider-menu ${providerMenuOpen ? "is-open" : ""}`,
												role: "listbox",
												"aria-hidden": !providerMenuOpen,
												children: providers.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													role: "option",
													"aria-selected": provider === item.id,
													tabIndex: providerMenuOpen ? 0 : -1,
													className: `custom-provider-option ${provider === item.id ? "selected" : ""}`,
													onClick: () => handleProviderChange(item.id),
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: `custom-provider-mark ${item.id}`,
															children: item.name.charAt(0)
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name }),
														provider === item.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "custom-provider-check",
															"aria-hidden": "true",
															children: "✓"
														})
													]
												}, item.id))
											})]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.apiKey }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "password",
										value: apiKey,
										placeholder: selectedProvider.placeholder,
										onChange: (event) => {
											setApiKey(event.target.value);
											setKeyStatus({
												message: "",
												type: ""
											});
										},
										autoComplete: "off",
										spellCheck: "false"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "advanced-meta",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: selectedProvider.keyUrl,
										target: "_blank",
										rel: "noreferrer",
										children: [t.getKey, " ↗"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.keyLocal })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "button-group",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											className: "primary-btn",
											onClick: handleSaveKey,
											children: t.saveAndUse
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											className: "secondary-btn",
											onClick: handleTestConnection,
											disabled: testing,
											children: t.test
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											className: "danger-btn",
											onClick: handleClearKey,
											children: t.clear
										})
									]
								}),
								keyStatus.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `status ${keyStatus.type}`,
									children: keyStatus.message
								})
							]
						})
					})]
				})
			]
		})]
	});
}
//#endregion
//#region src/settings/main.jsx
import_client.createRoot(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPage, {}) }));
//#endregion
